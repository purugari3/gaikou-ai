/* ============================================================
   GAIKOU AI DIAGNOSIS — Admin Console
   診断一覧 / 相談予約 / CSV出力 / 外部連携設定 / 将来拡張モジュール
   ============================================================ */
(function(){
  const cfg = window.GAIKOU_CONFIG || {};
  const DB  = window.GAIKOU_DB;
  const root = document.getElementById('admin-root');

  const state = {
    authed: sessionStorage.getItem('gaikou_admin_authed') === '1',
    tab: 'diagnoses',
    diagnoses: [],
    reservations: [],
    settings: {},
    expanded: null
  };

  /* ---------------------------------------------------------- */
  function render(){
    if(!state.authed){ renderLogin(); return; }
    root.innerHTML = `
      <div class="admin-shell">
        <div class="admin-header">
          <div>
            <span class="eyebrow">ADMIN CONSOLE</span>
            <h1>管理画面</h1>
            <p class="muted">${cfg.BRAND.company} ／ データ保存先: ${DB.backend}</p>
          </div>
          <button class="btn btn-outline" style="width:auto;" id="logout-btn">ログアウト</button>
        </div>

        <div class="admin-tabs">
          <button data-tab="diagnoses" class="${state.tab==='diagnoses'?'active':''}">診断一覧</button>
          <button data-tab="reservations" class="${state.tab==='reservations'?'active':''}">相談予約</button>
          <button data-tab="settings" class="${state.tab==='settings'?'active':''}">連携設定</button>
          <button data-tab="roadmap" class="${state.tab==='roadmap'?'active':''}">将来拡張モジュール</button>
        </div>

        <div id="tab-content"></div>
      </div>
    `;
    document.getElementById('logout-btn').addEventListener('click', () => {
      sessionStorage.removeItem('gaikou_admin_authed');
      state.authed = false;
      render();
    });
    root.querySelectorAll('.admin-tabs button').forEach(btn => {
      btn.addEventListener('click', () => { state.tab = btn.dataset.tab; renderTab(); });
    });
    renderTab();
  }

  function renderLogin(){
    root.innerHTML = `
      <div class="login-box bracket accent">
        <span class="br-tr"></span><span class="br-bl"></span>
        <span class="eyebrow">ADMIN LOGIN</span>
        <h2>管理画面ログイン</h2>
        <input type="password" id="pw" placeholder="パスワード">
        <button class="btn btn-primary" id="login-btn">ログイン</button>
        <p class="muted mt-4" id="login-error"></p>
      </div>
    `;
    const submit = () => {
      const pw = document.getElementById('pw').value;
      if(pw === cfg.ADMIN_PASSWORD){
        sessionStorage.setItem('gaikou_admin_authed', '1');
        state.authed = true;
        render();
      } else {
        document.getElementById('login-error').textContent = 'パスワードが正しくありません。';
      }
    };
    document.getElementById('login-btn').addEventListener('click', submit);
    document.getElementById('pw').addEventListener('keydown', (e) => { if(e.key==='Enter') submit(); });
  }

  /* ---------------------------------------------------------- */
  async function renderTab(){
    const c = document.getElementById('tab-content');
    if(state.tab === 'diagnoses'){
      c.innerHTML = `<p class="muted">読み込み中…</p>`;
      state.diagnoses = await DB.listDiagnoses();
      renderDiagnoses();
    } else if(state.tab === 'reservations'){
      c.innerHTML = `<p class="muted">読み込み中…</p>`;
      state.reservations = await DB.listReservations();
      renderReservations();
    } else if(state.tab === 'settings'){
      c.innerHTML = `<p class="muted">読み込み中…</p>`;
      state.settings = await DB.getSettings();
      renderSettings();
    } else if(state.tab === 'roadmap'){
      renderRoadmap();
    }
  }

  /* ---------------------------------------------------------- */
  function renderDiagnoses(){
    const c = document.getElementById('tab-content');
    if(state.diagnoses.length === 0){
      c.innerHTML = `<p class="muted">まだ診断データがありません。診断フォームから回答が送信されると、ここに一覧表示されます。</p>`;
      return;
    }
    c.innerHTML = `
      <div class="admin-actions">
        <button class="btn btn-outline" id="export-diagnoses">CSV出力</button>
        <span class="muted" style="align-self:center;">全 ${state.diagnoses.length} 件</span>
      </div>
      <div class="table-wrap">
        <table>
          <thead><tr>
            <th>日時</th><th>雰囲気</th><th>外構スタイル</th><th>予算</th>
            <th>駐車台数</th><th>カーポート</th><th>優先1位</th><th>ステータス</th><th></th>
          </tr></thead>
          <tbody>
            ${state.diagnoses.map((d,i) => {
              const a = d.answers || {};
              const cars = (a.carNormal||0)+(a.carKei||0);
              const pri = (a.priorities && a.priorities[0]) ? a.priorities[0].label : '-';
              return `<tr data-idx="${i}" style="cursor:pointer;">
                <td>${formatDate(d.created_at)}</td>
                <td>${a.atmosphere||'-'}</td>
                <td>${a.exteriorStyle||'-'}</td>
                <td>${a.budget||'-'}</td>
                <td>${cars}台</td>
                <td>${a.carport||'-'}</td>
                <td>${pri}</td>
                <td><span class="status-pill ${d.status==='done'?'done':'new'}">${d.status==='done'?'対応済':'新規'}</span></td>
                <td><button class="btn-text toggle-detail" data-idx="${i}">詳細</button></td>
              </tr>
              <tr class="detail-row ${state.expanded===i?'':'hidden'}" data-detail="${i}">
                <td colspan="9">${renderDiagnosisDetail(d)}</td>
              </tr>`;
            }).join('')}
          </tbody>
        </table>
      </div>
    `;
    document.getElementById('export-diagnoses').addEventListener('click', () => {
      const csv = DB.toCSV(state.diagnoses, [
        { label:'日時', value:d=>formatDate(d.created_at) },
        { label:'雰囲気', value:d=>(d.answers||{}).atmosphere },
        { label:'敷地面積', value:d=>(d.answers||{}).siteArea },
        { label:'敷地形状', value:d=>(d.answers||{}).siteShape },
        { label:'建坪', value:d=>(d.answers||{}).buildingArea },
        { label:'建物', value:d=>(d.answers||{}).buildingType },
        { label:'庭面積', value:d=>(d.answers||{}).gardenArea },
        { label:'普通車', value:d=>(d.answers||{}).carNormal },
        { label:'軽自動車', value:d=>(d.answers||{}).carKei },
        { label:'カーポート', value:d=>(d.answers||{}).carport },
        { label:'門柱', value:d=>(d.answers||{}).gatePost },
        { label:'宅配ボックス', value:d=>(d.answers||{}).deliveryBox },
        { label:'目隠しフェンス', value:d=>(d.answers||{}).fenceBlind },
        { label:'オープンフェンス', value:d=>(d.answers||{}).fenceOpen },
        { label:'人工芝', value:d=>(d.answers||{}).artificialGrass },
        { label:'ウッドデッキ', value:d=>(d.answers||{}).woodDeck },
        { label:'植栽', value:d=>(d.answers||{}).planting },
        { label:'外構スタイル', value:d=>(d.answers||{}).exteriorStyle },
        { label:'予算', value:d=>(d.answers||{}).budget },
        { label:'優先順位', value:d=>((d.answers||{}).priorities||[]).map(p=>p.label).join(' > ') },
        { label:'ステータス', value:d=>d.status }
      ]);
      DB.downloadCSV(`diagnoses_${dateStamp()}.csv`, csv);
    });
    c.querySelectorAll('.toggle-detail').forEach(btn => {
      btn.addEventListener('click', () => {
        const idx = parseInt(btn.dataset.idx, 10);
        state.expanded = state.expanded === idx ? null : idx;
        renderDiagnoses();
      });
    });
  }

  function renderDiagnosisDetail(d){
    const p = d.proposal || {};
    const patterns = p.patterns || [];
    return `
      <div style="padding:12px;">
        ${patterns.map(pt => `
          <div style="margin-bottom:12px;">
            <div class="muted" style="margin-bottom:4px;">${pt.label}（概算 ${pt.estimatedCost ? pt.estimatedCost.min+'〜'+pt.estimatedCost.max+'万円' : '-'}）</div>
            <p>${pt.concept || '-'}</p>
            ${(pt.points||[]).length ? `<ul>${pt.points.map(x=>`<li>${x}</li>`).join('')}</ul>` : ''}
            ${pt.imageUrl
              ? `<img src="${pt.imageUrl}" style="max-width:240px;">`
              : `<div class="muted">画像未生成${pt.imageNote ? ': ' + pt.imageNote : ''}</div>`}
          </div>
        `).join('')}
      </div>
    `;
  }

  /* ---------------------------------------------------------- */
  function renderReservations(){
    const c = document.getElementById('tab-content');
    if(state.reservations.length === 0){
      c.innerHTML = `<p class="muted">まだ相談予約がありません。</p>`;
      return;
    }
    c.innerHTML = `
      <div class="admin-actions">
        <button class="btn btn-outline" id="export-reservations">CSV出力</button>
        <span class="muted" style="align-self:center;">全 ${state.reservations.length} 件</span>
      </div>
      <div class="table-wrap">
        <table>
          <thead><tr>
            <th>日時</th><th>お名前</th><th>連絡先</th><th>方法</th><th>ご要望</th><th>ステータス</th>
          </tr></thead>
          <tbody>
            ${state.reservations.map(r => `
              <tr>
                <td>${formatDate(r.created_at)}</td>
                <td>${r.name||'-'}</td>
                <td>${r.contact||'-'}</td>
                <td>${methodLabel(r.method)}</td>
                <td style="max-width:240px; white-space:normal;">${r.message||'-'}</td>
                <td><span class="status-pill ${r.status==='done'?'done':'new'}">${r.status==='done'?'対応済':'新規'}</span></td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      </div>
    `;
    document.getElementById('export-reservations').addEventListener('click', () => {
      const csv = DB.toCSV(state.reservations, [
        { label:'日時', value:r=>formatDate(r.created_at) },
        { label:'お名前', value:r=>r.name },
        { label:'連絡先', value:r=>r.contact },
        { label:'相談方法', value:r=>methodLabel(r.method) },
        { label:'ご要望', value:r=>r.message },
        { label:'ステータス', value:r=>r.status }
      ]);
      DB.downloadCSV(`reservations_${dateStamp()}.csv`, csv);
    });
  }

  function methodLabel(m){
    return { zoom:'Zoom', online:'オンライン', visit:'現地', phone:'電話' }[m] || m || '-';
  }

  /* ---------------------------------------------------------- */
  function renderSettings(){
    const c = document.getElementById('tab-content');
    const s = state.settings || {};
    c.innerHTML = `
      <p class="muted" style="margin-bottom:16px;">
        Googleスプレッドシート連携・LINE通知は、Netlify Functions（<code>netlify/functions/notify.js</code>）から
        Google Apps Script Webhook / LINE Notify APIへ送信する構成です。下記URL・トークンは
        Netlifyの環境変数（<code>GAS_WEBHOOK_URL</code> / <code>LINE_NOTIFY_TOKEN</code>）に設定してください。
        このフォームの内容は管理画面の表示用に保存されます。
      </p>
      <div class="settings-grid">
        <div>
          <label>Google Apps Script Webhook URL</label>
          <input type="text" id="set-gas" value="${s.gas_webhook_url||''}" placeholder="https://script.google.com/macros/s/xxxx/exec">
          <div class="hint">スプレッドシートへの書き込み・LINE送信を行うApps Scriptの公開URL</div>
        </div>
        <div>
          <label>LINE Notify トークン（参考表示用）</label>
          <input type="text" id="set-line" value="${s.line_notify_token||''}" placeholder="xxxxxxxxxxxxxxxxxxxx">
          <div class="hint">実際の送信にはNetlifyの環境変数への設定が必要です</div>
        </div>
        <div>
          <label>担当者メール（通知先）</label>
          <input type="text" id="set-email" value="${s.notify_email||''}" placeholder="info@example.com">
        </div>
      </div>
      <button class="btn btn-primary mt-6" style="width:auto;" id="save-settings">保存する</button>
      <p class="muted mt-4" id="settings-status"></p>

      <h2 class="mt-6" style="margin-bottom:8px;">データベース接続</h2>
      <p class="muted">現在の保存先: <strong>${DB.backend}</strong></p>
      <p class="muted">Supabaseを利用する場合は <code>assets/config.js</code> に SUPABASE_URL / SUPABASE_ANON_KEY を設定し、
      <code>supabase-schema.sql</code> をSupabase上で実行してください。</p>
    `;
    document.getElementById('save-settings').addEventListener('click', async () => {
      const settings = {
        gas_webhook_url: document.getElementById('set-gas').value.trim(),
        line_notify_token: document.getElementById('set-line').value.trim(),
        notify_email: document.getElementById('set-email').value.trim()
      };
      await DB.saveSettings(settings);
      document.getElementById('settings-status').textContent = '保存しました。';
    });
  }

  /* ---------------------------------------------------------- */
  function renderRoadmap(){
    const c = document.getElementById('tab-content');
    const items = [
      { key:'estimateAI', title:'外構見積AI', desc:'回答内容と地域相場データから、項目別の概算見積を自動算出。診断結果カードに「見積を見る」を追加する構成で拡張可能です。' },
      { key:'perspectiveAI', title:'外構パースAI', desc:'生成済みイメージをもとに、視点・素材・色を変更した詳細パース図を複数パターン生成。generate-image.jsにバリエーション生成エンドポイントを追加して対応します。' },
      { key:'matching', title:'施工店マッチング', desc:'診断結果・エリア情報から提携施工店をマッチング。reservations テーブルに store_id を追加し、管理画面に振り分け機能を追加する想定です。' },
      { key:'diyPlan', title:'DIYプラン生成', desc:'予算が少ない／DIY志向のユーザー向けに、購入リストと施工手順を生成。新規Functionとプロンプトテンプレートを追加するだけで既存フローに合流できます。' }
    ];
    c.innerHTML = `
      <p class="muted" style="margin-bottom:16px;">
        以下は今後追加予定のAIモジュールです。<code>assets/config.js</code> の <code>FEATURES</code> フラグを
        <code>true</code> にすると、各機能のエントリーポイントを画面に表示する想定の拡張ポイントです。
      </p>
      <div class="table-wrap">
        <table>
          <thead><tr><th>モジュール</th><th>概要</th><th>状態</th></tr></thead>
          <tbody>
            ${items.map(i => `
              <tr>
                <td>${i.title}</td>
                <td style="white-space:normal; max-width:480px;">${i.desc}</td>
                <td><span class="status-pill">${cfg.FEATURES && cfg.FEATURES[i.key] ? '有効' : '準備中'}</span></td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      </div>
    `;
  }

  /* ---------------------------------------------------------- */
  function formatDate(iso){
    if(!iso) return '-';
    const d = new Date(iso);
    const p = (n) => String(n).padStart(2,'0');
    return `${d.getFullYear()}/${p(d.getMonth()+1)}/${p(d.getDate())} ${p(d.getHours())}:${p(d.getMinutes())}`;
  }
  function dateStamp(){
    const d = new Date();
    const p = (n) => String(n).padStart(2,'0');
    return `${d.getFullYear()}${p(d.getMonth()+1)}${p(d.getDate())}_${p(d.getHours())}${p(d.getMinutes())}`;
  }

  render();
})();
