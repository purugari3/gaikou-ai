/* ============================================================
   GAIKOU AI DIAGNOSIS — Data Layer
   Supabaseが設定されていればSupabaseへ、未設定ならlocalStorageへ保存します。
   将来的にバックエンドを差し替える際は、このファイルの実装だけを変更してください。
   ============================================================ */
(function(){
  const cfg = window.GAIKOU_CONFIG || {};
  const useSupabase = !!(cfg.SUPABASE_URL && cfg.SUPABASE_ANON_KEY);

  let supabase = null;
  if (useSupabase && window.supabase) {
    supabase = window.supabase.createClient(cfg.SUPABASE_URL, cfg.SUPABASE_ANON_KEY);
  }

  const LS_KEYS = {
    diagnoses: "gaikou_diagnoses",
    reservations: "gaikou_reservations",
    settings: "gaikou_settings"
  };

  function lsGet(key, fallback){
    try{
      const raw = localStorage.getItem(key);
      return raw ? JSON.parse(raw) : fallback;
    }catch(e){ return fallback; }
  }
  function lsSet(key, value){
    localStorage.setItem(key, JSON.stringify(value));
  }
  function uid(){
    return 'd_' + Date.now().toString(36) + '_' + Math.random().toString(36).slice(2,8);
  }

  const DB = {
    backend: supabase ? 'supabase' : 'localStorage',

    /* ---------------- 診断結果 ---------------- */
    async saveDiagnosis(record){
      record.id = record.id || uid();
      record.created_at = record.created_at || new Date().toISOString();
      record.status = record.status || 'new';

      if (supabase){
        const { data, error } = await supabase
          .from('diagnoses')
          .insert([record])
          .select()
          .single();
        if (error) { console.error('[DB] saveDiagnosis error', error); throw error; }
        return data;
      }
      const list = lsGet(LS_KEYS.diagnoses, []);
      list.unshift(record);
      lsSet(LS_KEYS.diagnoses, list);
      return record;
    },

    async listDiagnoses(){
      if (supabase){
        const { data, error } = await supabase
          .from('diagnoses')
          .select('*')
          .order('created_at', { ascending:false });
        if (error) { console.error('[DB] listDiagnoses error', error); return []; }
        return data || [];
      }
      return lsGet(LS_KEYS.diagnoses, []);
    },

    async updateDiagnosisStatus(id, status){
      if (supabase){
        const { error } = await supabase.from('diagnoses').update({ status }).eq('id', id);
        if (error) console.error('[DB] updateDiagnosisStatus error', error);
        return;
      }
      const list = lsGet(LS_KEYS.diagnoses, []);
      const item = list.find(d => d.id === id);
      if (item) item.status = status;
      lsSet(LS_KEYS.diagnoses, list);
    },

    /* ---------------- 相談予約 ---------------- */
    async saveReservation(record){
      record.id = record.id || uid();
      record.created_at = record.created_at || new Date().toISOString();
      record.status = record.status || 'new';

      if (supabase){
        const { data, error } = await supabase
          .from('reservations')
          .insert([record])
          .select()
          .single();
        if (error) { console.error('[DB] saveReservation error', error); throw error; }
        return data;
      }
      const list = lsGet(LS_KEYS.reservations, []);
      list.unshift(record);
      lsSet(LS_KEYS.reservations, list);
      return record;
    },

    async listReservations(){
      if (supabase){
        const { data, error } = await supabase
          .from('reservations')
          .select('*')
          .order('created_at', { ascending:false });
        if (error) { console.error('[DB] listReservations error', error); return []; }
        return data || [];
      }
      return lsGet(LS_KEYS.reservations, []);
    },

    /* ---------------- 設定（管理画面用） ---------------- */
    async getSettings(){
      if (supabase){
        const { data, error } = await supabase.from('settings').select('*').eq('id', 1).maybeSingle();
        if (error) { console.error('[DB] getSettings error', error); return {}; }
        return data || {};
      }
      return lsGet(LS_KEYS.settings, {});
    },

    async saveSettings(settings){
      if (supabase){
        const { error } = await supabase.from('settings').upsert({ id:1, ...settings });
        if (error) console.error('[DB] saveSettings error', error);
        return;
      }
      lsSet(LS_KEYS.settings, settings);
    },

    /* ---------------- CSV出力 ---------------- */
    toCSV(rows, columns){
      const esc = (v) => {
        if (v === null || v === undefined) return '';
        const s = typeof v === 'object' ? JSON.stringify(v) : String(v);
        return '"' + s.replace(/"/g, '""') + '"';
      };
      const header = columns.map(c => esc(c.label)).join(',');
      const body = rows.map(r => columns.map(c => esc(c.value(r))).join(',')).join('\r\n');
      return '\uFEFF' + header + '\r\n' + body; // BOM付きでExcel文字化け対策
    },

    downloadCSV(filename, csvContent){
      const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    }
  };

  window.GAIKOU_DB = DB;
})();
