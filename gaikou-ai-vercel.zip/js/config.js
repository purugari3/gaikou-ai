/* ============================================================
   GAIKOU AI DIAGNOSIS — Config
   この1ファイルだけ編集すれば外部連携を切り替えられます。
   未設定の項目は自動でローカル保存（localStorage）にフォールバックします。
   ============================================================ */
window.GAIKOU_CONFIG = {

  // ---- Supabase（任意）-------------------------------------------------
  // 診断結果・相談予約を永続保存する場合に設定します。
  // 未設定の場合は端末のlocalStorageに保存されます（管理画面の閲覧端末でのみ確認可）。
  // Supabaseのテーブル定義は supabase-schema.sql を参照してください。
  SUPABASE_URL: "",
  SUPABASE_ANON_KEY: "",

  // ---- サーバーレス関数（Vercel Functions）-----------------------------
  // api/ 配下にVercel Functionsとして接続。
  PROPOSAL_API: "/api/generate-proposal", // AI提案文生成（Claude API）
  IMAGE_API:    "/api/generate-image",    // AI外構画像生成
  NOTIFY_API:   "/api/notify",            // Googleスプレッドシート/LINE通知

  // ---- 管理画面 ----------------------------------------------------------
  // 簡易パスワードゲート。本番運用ではSupabase Authへの移行を推奨します。
  ADMIN_PASSWORD: "kadomatsu-2026",

  // ---- リード獲得 / 相談導線 -----------------------------------------------
  // 画像保存時にLINE公式アカウントへの登録を促す導線で使用するURL
  LINE_ADD_FRIEND_URL: "https://lin.ee/your-line-account",
  // 結果画面から直接Zoom相談に進めるURL（Zoomの個人ミーティングURL等）
  ZOOM_URL: "https://zoom.us/j/your-meeting-id",
  // Instagramシェア時の案内に使うアカウント情報
  INSTAGRAM: {
    handle: "@your_account",
    url: "https://www.instagram.com/your_account/"
  },

  // ---- ブランド ------------------------------------------------------------
  BRAND: {
    name: "AI外構コンシェルジュ",
    company: "可能性の実装家｜門松邦明",
    tagline: "全ては仕組みと導線設計。",
    subTagline: "目指すは、全国No.1の外構AIコンシェルジュ。",
    seoTitle: "AI外構コンシェルジュ｜AIが3パターンの完成イメージと見積感を提案",
    seoDescription: "AIが3パターンの外構プラン&完成イメージ・概算金額を無料診断。全国対応のAI外構コンシェルジュ。"
  },

  // ---- 将来拡張モジュール（フラグ）------------------------------------------
  // trueにすると各機能のエントリーポイントが画面に表示されます（実装は別途）。
  FEATURES: {
    estimateAI: false,   // 外構見積AI
    perspectiveAI: false,// 外構パースAI（詳細パース図生成）
    matching: false,     // 施工店マッチング
    diyPlan: false       // DIYプラン生成
  }
};
