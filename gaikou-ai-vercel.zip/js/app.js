/* ============================================================
   GAIKOU AI DIAGNOSIS — Diagnosis Wizard
   13STEPの診断フロー → AI提案文/画像生成 → 結果表示 → 相談予約
   ============================================================ */
(function(){
  const cfg = window.GAIKOU_CONFIG || {};
  const DB  = window.GAIKOU_DB;
  const TOTAL_STEPS = 13;
  const root = document.getElementById('app-root');

  // デバッグ用：未捕捉のエラー・Promise rejectionをコンソールに出力
  // （診断ボタン押下後に画面が止まる場合、ここに原因が表示されます）
  window.addEventListener('error', (e) => {
    console.error('[GAIKOU] Uncaught error:', e.message, e.error);
  });
  window.addEventListener('unhandledrejection', (e) => {
    console.error('[GAIKOU] Unhandled promise rejection:', e.reason);
  });

  /* ----------------------------------------------------------
     状態
     ---------------------------------------------------------- */
  const state = {
    screen: 'top', // top | step | loading | result
    step: 1,
    answers: {
      atmosphere: null,
      siteArea: '', siteAreaUnit: 'tsubo',
      siteShape: null,
      buildingArea: '', buildingAreaUnit: 'tsubo',
      buildingType: null,
      gardenArea: '', gardenAreaUnit: 'tsubo',
      carNormal: 0, carKei: 0,
      carport: null,
      gatePost: null, deliveryBox: null,
      fenceBlind: null, fenceOpen: null,
      artificialGrass: null, woodDeck: null, planting: null,
      exteriorStyle: null,
      budget: null,
      priorities: [
        { key:'design',    label:'①オシャレ・映え' },
        { key:'flow',      label:'②生活動線' },
        { key:'budget',    label:'③予算' },
        { key:'security',  label:'④防犯' },
        { key:'maintenance',label:'⑤メンテナンス' },
        { key:'childcare', label:'⑥子育て' }
      ],
      images: { building:null, layout:null, site:null, reference:null }
    },
    result: null,
    activePattern: 0,
    showReserve: false
  };

  /* ----------------------------------------------------------
     STEPメタ情報
     ---------------------------------------------------------- */
  const STEP_META = [
    { key:'atmosphere', eyebrow:'STEP 01 / 13', title:'家の雰囲気', sub:'仕上がりの方向性を選んでください' },
    { key:'site',       eyebrow:'STEP 02 / 13', title:'敷地情報',   sub:'敷地の広さと形状を入力してください' },
    { key:'building',   eyebrow:'STEP 03 / 13', title:'建物',       sub:'建坪と階数を入力してください' },
    { key:'garden',     eyebrow:'STEP 04 / 13', title:'庭',         sub:'庭として使う面積を入力してください' },
    { key:'parking',    eyebrow:'STEP 05 / 13', title:'駐車場',     sub:'駐車台数を入力してください' },
    { key:'carport',    eyebrow:'STEP 06 / 13', title:'カーポート', sub:'設置する台数を選んでください' },
    { key:'gate',       eyebrow:'STEP 07 / 13', title:'門まわり',   sub:'門柱・宅配ボックスの有無' },
    { key:'fence',      eyebrow:'STEP 08 / 13', title:'フェンス',   sub:'目隠し・オープンフェンスの有無' },
    { key:'garden2',    eyebrow:'STEP 09 / 13', title:'庭設備',     sub:'人工芝・ウッドデッキ・植栽の希望' },
    { key:'style',      eyebrow:'STEP 10 / 13', title:'外構スタイル', sub:'閉鎖性の方向性を選んでください' },
    { key:'budget',     eyebrow:'STEP 11 / 13', title:'予算',       sub:'おおよその予算感を選んでください' },
    { key:'priority',   eyebrow:'STEP 12 / 13', title:'優先順位',   sub:'重視するポイントを並び替えてください' },
    { key:'options',    eyebrow:'STEP 13 / 13', title:'オプション', sub:'参考になる画像があれば添付してください（任意）' }
  ];

  /* ----------------------------------------------------------
     ユーティリティ：UIパーツ
     ---------------------------------------------------------- */
  function choiceGrid(name, options, selected, opts){
    opts = opts || {};
    const cols = opts.singleCol ? ' single-col' : '';
    return `<div class="choice-grid${cols}" data-name="${name}">` +
      options.map(o => {
        const val = typeof o === 'string' ? o : o.value;
        const label = typeof o === 'string' ? o : o.label;
        const sub = (typeof o === 'object' && o.sub) ? `<span class="ci-sub">${o.sub}</span>` : '';
        const sel = selected === val ? ' selected' : '';
        return `<button type="button" class="choice-card${sel}" data-name="${name}" data-value="${val}">
                  <span class="ci-label">${label}</span>${sub}
                </button>`;
      }).join('') +
    `</div>`;
  }

  function numField(name, label, value, unit, opt){
    opt = opt ? `<span class="opt">${opt}</span>` : '';
    const isTsubo = unit === 'tsubo';
    return `<div class="field">
      <label class="field-label">${label}${opt}</label>
      <div class="num-input">
        <input type="number" inputmode="decimal" min="0" step="0.1" placeholder="0" value="${value}" data-num="${name}">
        <div class="unit-toggle" data-unit-for="${name}">
          <button type="button" class="${isTsubo?'active':''}" data-unit="tsubo">坪</button>
          <button type="button" class="${!isTsubo?'active':''}" data-unit="sqm">㎡</button>
        </div>
      </div>
    </div>`;
  }

  function toggleRow(name, label, sub, value){
    const yes = value === true, no = value === false;
    return `<div class="toggle-row" data-name="${name}">
      <div class="tr-label">${label}${sub?`<span class="tr-sub">${sub}</span>`:''}</div>
      <div class="toggle-group">
        <button type="button" class="${yes?'active':''}" data-name="${name}" data-value="true">あり</button>
        <button type="button" class="${no?'active':''}" data-name="${name}" data-value="false">なし</button>
      </div>
    </div>`;
  }

  function stepperRow(name, label, value, max){
    max = max || 5;
    return `<div class="stepper-row" data-name="${name}">
      <div class="sr-label">${label}</div>
      <div class="stepper">
        <button type="button" data-step="-1" data-name="${name}" ${value<=0?'disabled':''}>−</button>
        <div class="sval">${value}台</div>
        <button type="button" data-step="1" data-name="${name}" ${value>=max?'disabled':''}>＋</button>
      </div>
    </div>`;
  }

  function progressSVG(step){
    const w = 432, h = 28, pad = 16;
    const usable = w - pad*2;
    const gap = usable / (TOTAL_STEPS-1);
    let nodes = '', segs = '';
    for(let i=0;i<TOTAL_STEPS;i++){
      const x = pad + gap*i;
      const cls = i+1 < step ? 'node done' : (i+1===step ? 'node current' : 'node');
      nodes += `<circle class="${cls}" cx="${x}" cy="${h/2}" r="4"></circle>`;
      if(i>0){
        const x0 = pad + gap*(i-1);
        const filled = i <= step-1;
        segs += `<line class="${filled?'fill':'track'}" x1="${x0}" y1="${h/2}" x2="${x}" y2="${h/2}"></line>`;
      }
    }
    return `<svg class="progress-svg" viewBox="0 0 ${w} ${h}" preserveAspectRatio="none">${segs}${nodes}</svg>`;
  }

  /* ----------------------------------------------------------
     画面：TOP
     ---------------------------------------------------------- */
  function renderTop(){
    root.innerHTML = `
      <header class="app-header">
        <div class="brand">${cfg.BRAND.name}<small>${cfg.BRAND.company}</small></div>
      </header>
      <main class="app-main">
        <section class="hero bp-grid">
          <div class="hero-mark">FIG. 00 — ${cfg.BRAND.tagline}</div>
          <h1>理想の外構を、<br>AIが3分でカタチに。</h1>
          <p class="lead">「何から決めればいいか分からない」をゼロに。<br>質問に答えるだけで完成イメージと概算金額がわかります。</p>

          <div class="trust-row">
            <div class="trust-item"><span class="num">500<small>件+</small></span><span class="label">外構実績</span></div>
            <div class="trust-item"><span class="num">3<small>分</small></span><span class="label">診断時間</span></div>
            <div class="trust-item"><span class="num">無料</span><span class="label">セカンドオピニオン</span></div>
          </div>

          <svg class="hero-path" viewBox="0 0 400 120" preserveAspectRatio="none">
            <defs>
              <pattern id="grid" width="20" height="20" patternUnits="userSpaceOnUse">
                <path d="M 20 0 L 0 0 0 20" fill="none" stroke="#DCE8D8" stroke-width="1"/>
              </pattern>
            </defs>
            <rect width="400" height="120" fill="url(#grid)"/>
            <path d="M10 100 C 100 100, 100 20, 200 20 S 300 100, 390 30" fill="none" stroke="#5E8B65" stroke-width="2"/>
            <circle cx="10" cy="100" r="4" fill="#2B362E"/>
            <circle cx="390" cy="30" r="4" fill="#5E8B65"/>
            <text x="10" y="114" font-family="Space Mono, monospace" font-size="9" fill="#82917F">START</text>
            <text x="345" y="22" font-family="Space Mono, monospace" font-size="9" fill="#5E8B65">PLAN</text>
          </svg>
          <p class="muted center">${cfg.BRAND.subTagline}</p>
        </section>

        <section class="section">
          <div class="section-head">
            <span class="eyebrow">ISSUE</span>
            <h2>こんなお悩み、<br>ありませんか？</h2>
          </div>
          <div class="problem-card">
            <span class="pc-q">Q1</span>
            <p>予算感がわからないまま見積を取るのが不安。高すぎても、安すぎても怖い。</p>
          </div>
          <div class="problem-card">
            <span class="pc-q">Q2</span>
            <p>「こんな感じ」のイメージが業者にうまく伝わらず、打ち合わせが進まない。</p>
          </div>
          <div class="problem-card">
            <span class="pc-q">Q3</span>
            <p>デザイン・予算・動線…何を優先すればいいか決められず、結局後回しになる。</p>
          </div>
        </section>

        <section class="section bp-grid">
          <div class="section-head">
            <span class="eyebrow">SOLUTION</span>
            <h2>AIが、悩みを<br>「仕組み」で解決します</h2>
          </div>
          <div class="flow-timeline">
            <div class="flow-step">
              <div class="flow-num">1</div>
              <h3>3分の質問に回答</h3>
              <p>雰囲気・敷地・駐車場など13項目を選ぶだけ。専門知識は不要です。</p>
            </div>
            <div class="flow-step">
              <div class="flow-num">2</div>
              <h3>AIが3パターンを提案</h3>
              <p>予算重視・デザイン重視・動線重視の完成イメージと概算金額を自動生成します。</p>
            </div>
            <div class="flow-step accent">
              <div class="flow-num">3</div>
              <h3>気になれば無料相談へ</h3>
              <p>第三者目線のプロが、現地条件をふまえて具体的なプランに落とし込みます。</p>
            </div>
          </div>
        </section>

        <section class="section" style="padding-top:0;">
          <div class="feature-row">
            <div class="pill"><b>13</b>STEP診断</div>
            <div class="pill"><b>AI</b>完成イメージ ×3</div>
            <div class="pill"><b>500+</b>件の実績</div>
          </div>
        </section>
      </main>
      <div class="sticky-cta">
        <button class="btn btn-primary" id="start-btn">無料でAI外構を作る</button>
        <p class="muted center mt-4">所要時間 約3分・登録不要</p>
      </div>
    `;
    document.getElementById('start-btn').addEventListener('click', () => {
      state.screen = 'step';
      state.step = 1;
      render();
    });
  }

  /* ----------------------------------------------------------
     画面：STEP本体
     ---------------------------------------------------------- */
  function renderStep(){
    const meta = STEP_META[state.step-1];
    root.innerHTML = `
      <header class="app-header">
        <button class="btn-text" id="exit-btn">← TOP</button>
        <div class="brand" style="font-size:11px; letter-spacing:0.2em;">${cfg.BRAND.tagline}</div>
      </header>
      <div class="progress-wrap">
        <div class="progress-meta">
          <div class="step-no">${String(state.step).padStart(2,'0')}<span> / ${TOTAL_STEPS}</span></div>
          <div class="step-label">${meta.key}</div>
        </div>
        ${progressSVG(state.step)}
      </div>
      <main class="app-main">
        <div class="step-body bracket">
          <span class="br-tr"></span><span class="br-bl"></span>
          <div class="step-head">
            <span class="eyebrow">${meta.eyebrow}</span>
            <h2>${meta.title}</h2>
            <p class="muted">${meta.sub}</p>
          </div>
          <div id="step-content"></div>
        </div>
      </main>
      <div class="step-nav">
        <button class="btn btn-outline btn-back" id="back-btn" ${state.step===1?'disabled':''}>戻る</button>
        <button class="btn btn-primary" id="next-btn">${state.step===TOTAL_STEPS?'診断する':'次へ'}</button>
      </div>
    `;
    document.getElementById('exit-btn').addEventListener('click', () => {
      state.screen = 'top'; render();
    });
    document.getElementById('back-btn').addEventListener('click', () => {
      if(state.step>1){ state.step--; render(); }
    });
    document.getElementById('next-btn').addEventListener('click', onNext);

    renderStepContent();
    updateNextButton();
  }

  function renderStepContent(){
    const c = document.getElementById('step-content');
    const a = state.answers;
    switch(state.step){
      case 1:
        c.innerHTML = choiceGrid('atmosphere', [
          'シンプルモダン','ホテルライク','ナチュラル','北欧','和モダン','カリフォルニア','その他'
        ], a.atmosphere);
        break;

      case 2:
        c.innerHTML =
          numField('siteArea','敷地面積', a.siteArea, a.siteAreaUnit) +
          `<div class="field"><label class="field-label">敷地形状</label>` +
          choiceGrid('siteShape', ['正方形','長方形','旗竿地','変形地'], a.siteShape) +
          `</div>`;
        break;

      case 3:
        c.innerHTML =
          numField('buildingArea','建坪', a.buildingArea, a.buildingAreaUnit) +
          `<div class="field"><label class="field-label">建物</label>` +
          choiceGrid('buildingType', ['平屋','2階建て','3階建て']
            .map(v=>({value:v,label:v})), a.buildingType) +
          `</div>`;
        break;

      case 4:
        c.innerHTML = numField('gardenArea','庭面積', a.gardenArea, a.gardenAreaUnit);
        break;

      case 5:
        c.innerHTML =
          stepperRow('carNormal','普通車', a.carNormal) +
          stepperRow('carKei','軽自動車', a.carKei);
        break;

      case 6:
        c.innerHTML = choiceGrid('carport', ['なし','1台用','2台用','3台用'], a.carport);
        break;

      case 7:
        c.innerHTML =
          toggleRow('gatePost','門柱','表札・ポストを設置する柱', a.gatePost) +
          toggleRow('deliveryBox','宅配ボックス','不在時の荷物受け取り', a.deliveryBox);
        break;

      case 8:
        c.innerHTML =
          toggleRow('fenceBlind','目隠しフェンス','視線をカットするフェンス', a.fenceBlind) +
          toggleRow('fenceOpen','オープンフェンス','開放感のある低めのフェンス', a.fenceOpen);
        break;

      case 9:
        c.innerHTML =
          toggleRow('artificialGrass','人工芝','お手入れ不要の緑', a.artificialGrass) +
          toggleRow('woodDeck','ウッドデッキ','室内と庭をつなぐ空間', a.woodDeck) +
          `<div class="field mt-6"><label class="field-label">植栽</label>` +
          choiceGrid('planting', ['多め','少なめ','なし']
            .map(v=>({value:v,label:v})), a.planting, {singleCol:true}) +
          `</div>`;
        break;

      case 10:
        c.innerHTML = choiceGrid('exteriorStyle', [
          { value:'オープン外構', label:'オープン外構', sub:'開放的・スッキリ' },
          { value:'セミクローズ', label:'セミクローズ', sub:'バランス重視' },
          { value:'クローズ外構', label:'クローズ外構', sub:'防犯・プライバシー重視' }
        ], a.exteriorStyle, {singleCol:true});
        break;

      case 11:
        c.innerHTML = choiceGrid('budget', [
          '100万円以内','100〜200万円','200〜300万円','300〜500万円','500万円以上','未定'
        ], a.budget);
        break;

      case 12:
        c.innerHTML = `<ul class="priority-list" id="priority-list">` +
          a.priorities.map((p, i) => `
            <li class="priority-item" data-key="${p.key}">
              <div class="pi-rank">${String(i+1).padStart(2,'0')}</div>
              <div class="pi-label">${p.label}</div>
              <div class="pi-controls">
                <button type="button" data-dir="-1" data-idx="${i}" ${i===0?'disabled':''}>↑</button>
                <button type="button" data-dir="1" data-idx="${i}" ${i===a.priorities.length-1?'disabled':''}>↓</button>
              </div>
            </li>`).join('') +
          `</ul>
          <p class="muted">↑↓ボタンで重視する順に並び替えてください。</p>`;
        break;

      case 13:
        c.innerHTML = `<div class="upload-grid">` +
          [
            {key:'building', label:'建物写真'},
            {key:'layout', label:'配置図'},
            {key:'site', label:'敷地図'},
            {key:'reference', label:'参考画像'}
          ].map(t => {
            const img = a.images[t.key];
            return `<label class="upload-tile ${img?'has-file':''}" data-img="${t.key}">
              ${img?`<img class="thumb" src="${img}">`:''}
              <span class="ut-label">${img?'変更する':t.label}</span>
              <input type="file" accept="image/*" data-img-input="${t.key}">
            </label>`;
          }).join('') +
          `</div>
          <p class="muted mt-4">すべて任意です。アップロードした画像は診断のAI生成に活用されます。</p>`;
        break;
    }
    bindStepContent();
  }

  function bindStepContent(){
    const c = document.getElementById('step-content');
    const a = state.answers;

    // choice cards
    c.querySelectorAll('.choice-card').forEach(btn => {
      btn.addEventListener('click', () => {
        const name = btn.dataset.name, val = btn.dataset.value;
        a[name] = val;
        renderStepContent();
        updateNextButton();
      });
    });

    // number inputs
    c.querySelectorAll('input[data-num]').forEach(inp => {
      inp.addEventListener('input', () => {
        a[inp.dataset.num] = inp.value;
        updateNextButton();
      });
    });

    // unit toggles
    c.querySelectorAll('.unit-toggle button').forEach(btn => {
      btn.addEventListener('click', () => {
        const target = btn.parentElement.dataset.unitFor;
        a[target + 'Unit'] = btn.dataset.unit;
        renderStepContent();
      });
    });

    // toggle rows
    c.querySelectorAll('.toggle-group button').forEach(btn => {
      btn.addEventListener('click', () => {
        a[btn.dataset.name] = btn.dataset.value === 'true';
        renderStepContent();
        updateNextButton();
      });
    });

    // steppers
    c.querySelectorAll('.stepper button').forEach(btn => {
      btn.addEventListener('click', () => {
        const name = btn.dataset.name;
        const dir = parseInt(btn.dataset.step, 10);
        let v = (a[name] || 0) + dir;
        v = Math.max(0, Math.min(5, v));
        a[name] = v;
        renderStepContent();
      });
    });

    // priority list
    c.querySelectorAll('.priority-item .pi-controls button').forEach(btn => {
      btn.addEventListener('click', () => {
        const idx = parseInt(btn.dataset.idx, 10);
        const dir = parseInt(btn.dataset.dir, 10);
        const list = a.priorities;
        const target = idx + dir;
        if(target < 0 || target >= list.length) return;
        [list[idx], list[target]] = [list[target], list[idx]];
        renderStepContent();
      });
    });

    // image uploads
    c.querySelectorAll('input[data-img-input]').forEach(inp => {
      inp.addEventListener('change', (e) => {
        const file = e.target.files[0];
        if(!file) return;
        const key = inp.dataset.imgInput;
        const reader = new FileReader();
        reader.onload = () => {
          a.images[key] = reader.result;
          renderStepContent();
        };
        reader.readAsDataURL(file);
      });
    });
  }

  /* ----------------------------------------------------------
     ナビゲーション / バリデーション
     ---------------------------------------------------------- */
  function isStepValid(step){
    const a = state.answers;
    switch(step){
      case 1: return !!a.atmosphere;
      case 2: return !!a.siteShape;
      case 3: return !!a.buildingType;
      case 4: return true;
      case 5: return true;
      case 6: return !!a.carport;
      case 7: return a.gatePost !== null && a.deliveryBox !== null;
      case 8: return a.fenceBlind !== null && a.fenceOpen !== null;
      case 9: return a.artificialGrass !== null && a.woodDeck !== null && !!a.planting;
      case 10: return !!a.exteriorStyle;
      case 11: return !!a.budget;
      case 12: return true;
      case 13: return true;
      default: return true;
    }
  }

  function updateNextButton(){
    const btn = document.getElementById('next-btn');
    if(!btn) return;
    btn.disabled = !isStepValid(state.step);
  }

  function onNext(){
    if(!isStepValid(state.step)) return;
    if(state.step < TOTAL_STEPS){
      state.step++;
      render();
    } else {
      runDiagnosis().catch(err => {
        console.error('[runDiagnosis] 予期しないエラーで停止しました', err);
        // 想定外のエラーでも結果画面を表示できるよう、ローカル生成にフォールバックして復旧する
        const a = state.answers;
        const proposal = mockProposals(a);
        proposal.patterns.forEach(p => { p.imageUrl = null; });
        state.result = { proposal, createdAt: new Date().toISOString() };
        state.activePattern = 0;
        state.screen = 'result';
        render();
      });
    }
  }

  /* ----------------------------------------------------------
     画面：ローディング
     ---------------------------------------------------------- */
  const LOADING_MESSAGES = [
    'AIが理想の外構を考えています',
    '植栽を選んでいます',
    '動線を設計しています',
    '素材とカラーを調整しています',
    '完成イメージを描いています'
  ];

  function renderLoading(){
    root.innerHTML = `
      <main class="app-main bp-grid">
        <div class="loading-screen">
          <span class="eyebrow">AI DESIGNING</span>
          <div class="loading-bar"></div>
          <h2 id="loading-message" class="loading-message show">${LOADING_MESSAGES[0]}</h2>
          <p class="muted">しばらくお待ちください（混雑時は1分程度かかる場合があります）</p>
        </div>
      </main>
    `;

    if(state.loadingInterval) clearInterval(state.loadingInterval);
    let idx = 0;
    state.loadingInterval = setInterval(() => {
      idx = (idx + 1) % LOADING_MESSAGES.length;
      const el = document.getElementById('loading-message');
      if(!el){ clearInterval(state.loadingInterval); state.loadingInterval = null; return; }
      el.classList.remove('show');
      setTimeout(() => {
        el.textContent = LOADING_MESSAGES[idx];
        el.classList.add('show');
      }, 220);
    }, 2200);
  }

  // 各ステップの完了をデバッグログに出力（UI表示はローテーションメッセージに任せる）
  function markLoading(key){
    console.log('[diagnosis] step done:', key);
  }

  /* ----------------------------------------------------------
     診断実行：AI提案文・画像生成
     ---------------------------------------------------------- */
  // STEP13でアップロードされた画像（base64）はサイズが大きく、そのままAPIに送ると
  // ペイロード超過でリクエスト自体が失敗する原因になるため、送信用には
  // 「添付があったかどうか」のフラグのみに変換する。
  function buildApiAnswers(a){
    return {
      ...a,
      images: {
        building: !!(a.images && a.images.building),
        layout: !!(a.images && a.images.layout),
        site: !!(a.images && a.images.site),
        reference: !!(a.images && a.images.reference)
      }
    };
  }

  // 1パターン分の完成イメージを生成する（初回診断・再生成ボタンの両方から使用）
  async function fetchImage(a, apiAnswers, patternKey){
    try{
      console.log(`[image:${patternKey}] fetch開始`);
      const res = await fetch(cfg.IMAGE_API, {
        method:'POST',
        headers:{'Content-Type':'application/json'},
        body: JSON.stringify({ prompt: buildImagePrompt(a, patternKey), answers: apiAnswers, pattern: patternKey })
      });
      console.log(`[image:${patternKey}] generate-image response status:`, res.status);

      const data = await res.json().catch(() => null);
      console.log(`[image:${patternKey}] generate-image response body:`, data);
      console.log(`[image:${patternKey}] imageUrl present:`, !!(data && data.imageUrl));
      console.log(`[image:${patternKey}] imageBase64 present:`, !!(data && data.imageBase64));

      if(!data){
        return { imageUrl: null, note: `画像APIの応答を解析できませんでした (HTTP ${res.status})` };
      }
      if(!res.ok || data.success === false){
        return { imageUrl: null, note: data.error || `画像生成エラー (HTTP ${res.status})` };
      }

      // imageUrl（dataURI/URLそのまま）を優先し、無ければimageBase64からdataURIを組み立てる
      let imageUrl = data.imageUrl || null;
      if(!imageUrl && data.imageBase64){
        imageUrl = `data:image/png;base64,${data.imageBase64}`;
      }
      if(!imageUrl){
        return { imageUrl: null, note: data.error || '画像生成APIから画像が返却されませんでした。' };
      }
      return { imageUrl, note: null };
    }catch(e){
      console.warn(`[image:${patternKey}] fetchに失敗しました`, e);
      return { imageUrl: null, note: `画像生成リクエストに失敗しました: ${e.message || e}` };
    }
  }

  // 生成済み画像をlocalStorageに保存（デバッグ・再表示用）
  function persistLastImages(proposal){
    try{
      localStorage.setItem('gaikou_last_images', JSON.stringify(
        proposal.patterns.map(p => ({ key: p.key, label: p.label, imageUrl: p.imageUrl, note: p.imageNote }))
      ));
    }catch(e){ console.warn('[localStorage] 画像の保存に失敗しました', e); }
  }

  async function runDiagnosis(){
    state.screen = 'loading';
    render();

    const a = state.answers;
    await sleep(250);
    markLoading('answers');

    const apiAnswers = buildApiAnswers(a);

    let proposal;
    console.log('[diagnosis] PROPOSAL_API へリクエスト送信:', cfg.PROPOSAL_API);
    try{
      const res = await fetch(cfg.PROPOSAL_API, {
        method:'POST',
        headers:{'Content-Type':'application/json'},
        body: JSON.stringify({ answers: apiAnswers })
      });
      console.log('[diagnosis] PROPOSAL_API レスポンス:', res.status);
      if(!res.ok){
        const errText = await res.text().catch(() => '');
        console.error('[proposal] generate-proposal がエラーを返しました:', res.status, errText);
        throw new Error('proposal api error: ' + res.status);
      }
      proposal = await res.json();
    }catch(e){
      console.warn('[proposal] APIが未接続/エラーのためローカル生成を使用します', e);
      await sleep(400);
      proposal = mockProposals(a);
    }

    // proposalの形式が不正な場合（古いFunctionのレスポンス等）はローカル生成にフォールバック
    if(!proposal || !Array.isArray(proposal.patterns) || proposal.patterns.length !== 3){
      console.warn('[proposal] レスポンス形式が不正なためローカル生成を使用します', proposal);
      proposal = mockProposals(a);
    }
    markLoading('proposal');

    // 3パターン（予算重視・デザイン重視・動線重視）それぞれの完成イメージを並列生成
    console.log('[diagnosis] IMAGE_API へ3パターンの画像生成リクエストを送信:', cfg.IMAGE_API);

    const imageResults = await Promise.all(
      proposal.patterns.map(p => fetchImage(a, apiAnswers, p.key))
    );
    proposal.patterns.forEach((p, i) => {
      p.imageUrl = imageResults[i].imageUrl;
      p.imageNote = imageResults[i].note;
    });
    markLoading('image');
    await sleep(200);

    state.result = { proposal, createdAt: new Date().toISOString() };
    state.activePattern = 0;

    // 生成した3パターンの画像をlocalStorageにも保存（デバッグ・再表示用）
    persistLastImages(proposal);

    // 保存（バックグラウンド・失敗しても結果表示は継続）
    DB.saveDiagnosis({
      answers: a,
      proposal: proposal,
      image_url: proposal.patterns[0] ? proposal.patterns[0].imageUrl : null
    }).catch(err => console.warn('[DB] 保存に失敗しました', err));

    state.screen = 'result';
    render();
  }

  function sleep(ms){ return new Promise(r => setTimeout(r, ms)); }

  /* ----------------------------------------------------------
     AI画像生成プロンプト構築
     ---------------------------------------------------------- */
  function buildImagePrompt(a, patternKey){
    const base = "Photorealistic Japanese residential exterior design (gaikou/exterior landscaping), " +
      "natural modern house, lush green planting, well-kept lawn, wood-grain fence, " +
      "grey tile deck, paved approach and parking area, " +
      "simple and clean composition, abundant natural greenery, " +
      "bright daytime sunlight, soft natural light, premium high-end finish, " +
      "Scandinavian-influenced natural modern style, " +
      "ultra realistic CG quality, 8k, architectural visualization";

    const atmosphereMap = {
      'シンプルモダン':'minimalist modern architecture, monochrome palette with greenery accents',
      'ホテルライク':'boutique hotel entrance, resort-style luxury greenery',
      'ナチュラル':'natural materials, warm wood and abundant greenery',
      '北欧':'scandinavian natural modern design, light wood and white facade, green lawn',
      '和モダン':'modern Japanese aesthetic, dark wood lattice, zen garden planting',
      'カリフォルニア':'california casual style, white stucco walls, lush palm-like planting',
      'その他':'custom designer exterior with natural greenery'
    };
    const styleMap = {
      'オープン外構':'open-style exterior, no walls, inviting green curb appeal',
      'セミクローズ':'semi-enclosed exterior with low wood-grain fence and planting screens',
      'クローズ外構':'fully enclosed exterior with high wood-grain privacy fence and gated entrance'
    };

    const parts = [base];
    if(atmosphereMap[a.atmosphere]) parts.push(atmosphereMap[a.atmosphere]);
    if(styleMap[a.exteriorStyle]) parts.push(styleMap[a.exteriorStyle]);
    if(a.carport && a.carport !== 'なし') parts.push(`${a.carport.replace('台用',' car')} carport`);
    if((a.carNormal||0) + (a.carKei||0) > 0) parts.push(`${(a.carNormal||0)+(a.carKei||0)} parking spaces, paved approach`);
    if(a.fenceBlind) parts.push('wood-grain privacy fence');
    if(a.fenceOpen) parts.push('open-style low wood-grain fence');
    if(a.woodDeck) parts.push('tile deck terrace connecting to garden');
    if(a.artificialGrass) parts.push('neat green lawn (artificial turf)');
    if(a.planting === '多め') parts.push('lush abundant planting, layered greenery, symbolic tree such as Aodamo');
    if(a.planting === '少なめ') parts.push('minimal accent planting with neat greenery');
    if(a.gatePost) parts.push('designer gate pillar with nameplate, planting and soft lighting');
    if(a.deliveryBox) parts.push('built-in delivery box');

    const patternBiasMap = {
      budget: 'cost-efficient natural materials, simple clean layout, practical green finish',
      design: 'premium natural finish materials, designer planting, symbolic tree, magazine-quality natural composition',
      flow: 'clear walking path from car to entrance through green approach, functional layout emphasizing daily usability'
    };
    if(patternBiasMap[patternKey]) parts.push(patternBiasMap[patternKey]);

    return parts.join(', ');
  }

  /* ----------------------------------------------------------
     予算レンジ・配分の共通ロジック
     ---------------------------------------------------------- */
  function budgetRange(b){
    const map = {
      '100万円以内': [60, 100],
      '100〜200万円': [100, 200],
      '200〜300万円': [200, 300],
      '300〜500万円': [300, 500],
      '500万円以上': [500, 800],
      '未定': [150, 300]
    };
    return map[b] || [150, 300];
  }

  function baseAllocationWeights(a){
    const totalCars = (a.carNormal||0) + (a.carKei||0);
    let driveway = totalCars > 0 ? 30 : 15;
    let carport = (a.carport && a.carport !== 'なし') ? 20 : 0;
    let gate = (a.gatePost || a.deliveryBox) ? 12 : 6;
    let fence = (a.fenceBlind || a.fenceOpen) ? 15 : 8;
    let garden = 100 - driveway - carport - gate - fence;
    if(garden < 8) garden = 8;
    return { driveway, carport, gate, fence, garden };
  }

  function buildAllocation(a, biasFn){
    const w = biasFn({ ...baseAllocationWeights(a) });
    Object.keys(w).forEach(k => { if(w[k] < 0) w[k] = 0; });
    const sum = Object.values(w).reduce((s,v)=>s+v,0) || 1;
    const norm = (v) => Math.round(v / sum * 100);

    const items = [
      { label:'駐車スペース・土間', percent: norm(w.driveway), note:'駐車場・アプローチの土間コンクリート、舗装材' }
    ];
    if(w.carport) items.push({ label:'カーポート', percent: norm(w.carport), note: (a.carport||'カーポート') + 'の構造体・設置費' });
    items.push({ label:'門まわり・フェンス', percent: norm(w.gate + w.fence), note:'門柱、宅配ボックス、フェンス類' });
    items.push({ label:'庭・植栽・設備', percent: norm(w.garden), note:'植栽、人工芝、ウッドデッキ等' });
    return items;
  }

  function buildScore(breakdown){
    const entries = Object.entries(breakdown);
    const total = Math.round(entries.reduce((s,[,v])=>s+v,0) / entries.length);
    return {
      total,
      breakdown: entries.map(([label, value]) => ({ label, value }))
    };
  }

  /* ----------------------------------------------------------
     ローカル提案文生成（AI APIが未接続の場合のフォールバック）
     3パターン（予算重視・デザイン重視・動線重視）を生成します。
     ---------------------------------------------------------- */
  function mockProposals(a){
    const totalCars = (a.carNormal||0) + (a.carKei||0);
    const atmosphere = a.atmosphere || 'シンプルモダン';
    const style = a.exteriorStyle || 'セミクローズ';
    const carportLabel = (a.carport && a.carport !== 'なし') ? a.carport : '駐車スペース';
    const range = budgetRange(a.budget);

    /* ---- パターン①：予算重視 ---- */
    const budgetPattern = {
      key:'budget', label:'予算重視', icon:'BUDGET',
      highlight:'コストを抑えながら、必要な機能をしっかり満たすプラン',
      estimatedCost: { min: range[0], max: Math.round(range[1]*0.85) },
      concept: `予算を最優先に、${style}スタイルをベースに必要な機能を絞り込んだプランです。`
        + `${totalCars}台分の駐車スペースと${carportLabel}を基本構成としながら、フェンスや植栽は仕様をシンプルにすることでコストを抑えます。`
        + `今すぐ必要ない部分は将来工事として残し、初期費用を最小限にします。`,
      points: [
        `${carportLabel}は既製品ベースのシンプルな仕様にし、機能を保ちながらコストを抑えます。`,
        a.fenceOpen ? 'オープンフェンスを基本とし、フェンス費用を抑えながら開放感を確保します。'
                    : '目隠しが必要な箇所だけにフェンスを絞り、コストを最適化します。',
        a.artificialGrass ? '人工芝でお手入れコストを削減しつつ、見栄えを維持します。'
                           : '植栽は必要な箇所に絞り、初期費用とメンテナンス費用を抑えます。',
        `${style}の方向性は保ちつつ、優先度の低い装飾は将来の追加工事として計画できます。`
      ],
      budgetAllocation: buildAllocation(a, w => { w.fence += 4; w.garden -= 4; return w; }),
      score: buildScore({ デザイン性:72, 予算適正:96, 動線:78, 将来性:82 }),
      savingPoints: [
        `${carportLabel}・フェンスは既製品グレードを選び、初期費用を約1〜2割削減できます。`,
        '植栽は最小限にし、必要に応じて後から自分で追加することで初期費用を抑えられます。',
        '土間コンクリートなど複数工事をまとめて発注すると、別途工事費（重複する諸経費）を削減できます。'
      ]
    };

    /* ---- パターン②：デザイン重視 ---- */
    const designPattern = {
      key:'design', label:'デザイン重視', icon:'DESIGN',
      highlight:`「${atmosphere}」の世界観を最大限に表現するプラン`,
      estimatedCost: { min: Math.round(range[0]*1.15), max: Math.round(range[1]*1.35) },
      concept: `「${atmosphere}」の世界観を表現することを最優先したプランです。`
        + `外壁・フェンス・植栽の素材とカラーを統一し、${a.gatePost ? '門柱のデザインと照明' : 'アプローチの仕上げ'}にもこだわることで、`
        + `毎日帰るたびに気持ちが上がる、写真映えする上質な外観をつくります。`,
      points: [
        `「${atmosphere}」のテイストに合わせ、外構全体の素材・カラーを統一してまとまりのある外観にします。`,
        a.gatePost ? 'デザイン性の高い門柱とライティングで、夜間も上質な印象を演出します。'
                   : 'アプローチ部分の舗装材にこだわり、外観全体の印象を引き上げます。',
        a.planting === '多め' ? 'シンボルツリーと季節の植栽を組み合わせ、四季を感じる豊かな表情をつくります。'
                              : '視線が集まる場所に厳選した植栽を配置し、印象的なアクセントにします。',
        a.carport && a.carport !== 'なし' ? `${a.carport}は外観に合わせたデザインカラーを採用します。`
                                            : '駐車スペースも外観の一部として、舗装材の質感にこだわります。'
      ],
      budgetAllocation: buildAllocation(a, w => { w.garden += 8; w.driveway -= 4; w.gate -= 4; return w; }),
      score: buildScore({ デザイン性:97, 予算適正:68, 動線:80, 将来性:85 }),
      savingPoints: [
        'グレードを上げる箇所を1〜2か所（門柱・植栽など）に絞ることで、印象とコストのバランスを最適化できます。',
        'プランターや小物などDIYで対応できる部分は外注せず自分で揃えると、装飾コストを抑えられます。',
        '同じ素材・カラーで統一発注することで、施工の手間とコストを削減できます。'
      ]
    };

    /* ---- パターン③：動線重視 ---- */
    const flowPattern = {
      key:'flow', label:'動線重視', icon:'FLOW',
      highlight:'毎日の暮らしやすさ・家事ラクを最優先したプラン',
      estimatedCost: { min: range[0], max: range[1] },
      concept: `毎日の暮らしやすさを最優先したプランです。`
        + `${totalCars}台の駐車スペースから玄関までの動線を最短化し、`
        + `${a.deliveryBox ? '宅配ボックスでの荷物受け取りから、' : ''}`
        + `${a.woodDeck ? 'ウッドデッキを経由した庭への移動まで、' : '庭への移動まで、'}`
        + `家事や子育ての負担を減らすレイアウトを重視します。`,
      points: [
        `駐車スペースから玄関までの距離を最短化し、雨の日でも濡れにくいルートを確保します。`,
        a.deliveryBox ? '宅配ボックスは外からも取り出せる位置に設置し、家事の合間でも対応しやすくします。'
                       : '来客対応と日常の出入りの動線を分けて計画し、混雑を防ぎます。',
        a.woodDeck ? 'ウッドデッキを経由してリビングと庭をつなぎ、洗濯物の運搬や子どもの行き来をスムーズにします。'
                    : '庭への出入り口を生活動線上に配置し、無駄な移動を減らします。',
        a.priorities[0] && a.priorities[0].key === 'childcare'
          ? '子どもの行動範囲を見守りやすいレイアウトを最優先します。'
          : `${totalCars}台の駐車を想定し、出し入れのしやすさを優先した配置にします。`
      ],
      budgetAllocation: buildAllocation(a, w => { w.driveway += 6; w.gate += 4; w.garden -= 10; return w; }),
      score: buildScore({ デザイン性:78, 予算適正:80, 動線:97, 将来性:83 }),
      savingPoints: [
        '駐車スペースの舗装は動線に直結する範囲に絞り、無駄な土間コンクリートを削減できます。',
        '宅配ボックス・物置などは規格品を選定し、オーダー品との価格差をコストダウンに充てられます。',
        '将来の設備追加（カーポート増設等）を見据えた配管・配線だけ先行することで、二重工事を防げます。'
      ]
    };

    /* ---- 共通セクション（動線・植栽・将来性） ---- */
    const flowParts = [];
    flowParts.push(`駐車スペース(${totalCars}台)から玄関までは最短ルートを基本に計画し、雨天時も濡れにくい屋根付きアプローチを検討します。`);
    if(a.deliveryBox) flowParts.push('宅配ボックスは門柱付近に設置し、来客対応と荷物受け取りの動線を分離します。');
    if(a.woodDeck) flowParts.push('リビング側はウッドデッキを介して庭へ出られる動線を確保し、家事や子どもの行き来をスムーズにします。');
    if(a.priorities[0] && a.priorities[0].key === 'childcare') flowParts.push('子育てを最優先事項として、駐車スペースから玄関までの距離を短くし、見守りやすい配置を重視します。');
    if(a.priorities[0] && a.priorities[0].key === 'security') flowParts.push('防犯性を最優先とし、外部からの視認性と死角の少ない配置を重視します。');

    let plantingText;
    if(a.planting === '多め'){
      plantingText = '常緑樹を背景に、四季ごとに見頃を迎える低木・下草を組み合わせ、年間を通して緑を楽しめる構成にします。シンボルツリーを1本設けると、外観全体の印象がぐっと引き締まります。';
    } else if(a.planting === '少なめ'){
      plantingText = '玄関周辺やフェンス際など視線が集まる場所に絞って植栽を配置し、メンテナンスの手間を抑えながらアクセントをつくります。';
    } else {
      plantingText = '植栽は最小限とし、舗装やフェンスなど構造物の質感で表情をつくる構成にします。将来的に植栽を追加できるスペースは確保しておくと安心です。';
    }

    const futureParts = [];
    futureParts.push('将来的なライフスタイルの変化（車の台数増減、子どもの成長、来客の増加など）を見据え、駐車スペースや庭の用途を柔軟に変更できる余白を持たせています。');
    if(a.priorities.some((p,i)=> p.key==='maintenance' && i < 3)){
      futureParts.push('メンテナンス性を重視されているため、経年変化が少ない素材・人工芝の活用を優先的にご提案します。');
    }
    futureParts.push('外構は一度作ると変更コストが大きいため、配管・配線・コンセント位置などは将来の設備追加を想定して計画することをおすすめします。');

    /* ---- DIYアドバイス（共通） ---- */
    const diyAdvice = [
      '人工芝の設置やプランターの配置・植栽の植え付けは、下地づくりを施工店に依頼した上でDIYでも対応可能です。',
      '照明・ポスト・表札などの小物は、ホームセンターやネット通販で購入し、ご自身で取り付けることでコストを抑えられます。',
      'フェンスや木部の塗装・メンテナンスは数年ごとにDIYで行うと、長期的な維持費を削減できます。',
      '土間コンクリートや給排水・電気工事など、安全性に関わる部分は専門業者への依頼を強くおすすめします。'
    ];

    return {
      patterns: [budgetPattern, designPattern, flowPattern],
      flow: flowParts.join('\n'),
      planting: plantingText,
      future: futureParts.join('\n'),
      diyAdvice
    };
  }

  /* ----------------------------------------------------------
     画面：結果
     ---------------------------------------------------------- */
  function renderResult(){
    const { proposal } = state.result;
    const a = state.answers;
    const patterns = proposal.patterns;
    const active = patterns[state.activePattern] || patterns[0];

    let imageBlock;
    if(active.imageLoading){
      imageBlock = `<div class="ri-placeholder">
           <div class="ri-spinner"></div>
           <span class="ri-title">画像を生成しています</span>
           <span>少々お待ちください…</span>
         </div>`;
    } else if(active.imageUrl){
      imageBlock = `<img src="${active.imageUrl}" alt="AI生成イメージ（${active.label}）">`;
    } else {
      imageBlock = `<div class="ri-placeholder">
           <span class="ri-title">画像を生成しています</span>
           <span>混雑状況により少し時間がかかっています</span>
           <button type="button" class="btn btn-outline" id="retry-image-btn" data-pattern="${state.activePattern}">もう一度生成する</button>
         </div>`;
    }

    root.innerHTML = `
      <header class="app-header">
        <button class="btn-text" id="exit-btn">← TOP</button>
        <div class="brand" style="font-size:11px; letter-spacing:0.2em;">${cfg.BRAND.tagline}</div>
      </header>
      <main class="app-main is-result">
        <div class="result-image">
          <span class="ri-tag">AI GENERATED — ${active.label}</span>
          ${imageBlock}
        </div>
        <div class="image-actions">
          <button class="btn btn-outline" id="save-image-btn">画像を保存する</button>
        </div>

        <div class="result-title">
          <span class="eyebrow">RESULT — 3 PATTERNS</span>
          <h1>あなたにおすすめの<br>外構プラン</h1>
          <p class="muted mt-4">予算重視・デザイン重視・動線重視の3パターンを生成しました。タップして切り替えられます。</p>
        </div>

        <div class="pattern-tabs" id="pattern-tabs">
          ${patterns.map((p,i) => `
            <button type="button" class="pattern-tab ${i===state.activePattern?'active':''}" data-pattern="${i}">
              <span class="pt-icon">${p.icon}</span>
              <span class="pt-label">${p.label}</span>
            </button>
          `).join('')}
        </div>

        <div class="result-cards">
          <div class="result-card">
            <div class="rc-head"><span class="rc-no">01</span><span class="rc-title">総合評価</span></div>
            <span class="highlight-badge">${active.highlight}</span>
            <div class="score-total"><span class="score-num">${active.score.total}</span><span class="score-unit">/ 100点</span></div>
            <div class="score-bars">
              ${active.score.breakdown.map(b => `
                <div>
                  <div style="display:flex; justify-content:space-between; font-size:12px;">
                    <span>${b.label}</span><span class="muted">${b.value}</span>
                  </div>
                  <div class="budget-bar"><div class="fill" style="width:${b.value}%"></div></div>
                </div>
              `).join('')}
            </div>
          </div>

          <div class="result-card">
            <div class="rc-head"><span class="rc-no">02</span><span class="rc-title">コンセプト</span></div>
            <div class="rc-body">${active.concept}</div>
          </div>

          <div class="result-card">
            <div class="rc-head"><span class="rc-no">03</span><span class="rc-title">概算金額とメリット</span></div>
            <div class="cost-badge">
              <span class="cb-label">ESTIMATED COST</span>
              <span class="cb-value">${active.estimatedCost.min}万円 〜 ${active.estimatedCost.max}万円</span>
              <span class="cb-note">敷地条件・仕様により変動します（目安）</span>
            </div>
            <div class="rc-body"><ul>${active.points.map(p=>`<li>${p}</li>`).join('')}</ul></div>
          </div>

          <div class="result-card">
            <div class="rc-head"><span class="rc-no">04</span><span class="rc-title">予算配分イメージ</span></div>
            <div class="rc-body">
              ${active.budgetAllocation.map(b => `
                <div>
                  <div style="display:flex; justify-content:space-between; font-size:12px;">
                    <span>${b.label}</span><span class="muted">${b.percent}%</span>
                  </div>
                  <div class="budget-bar"><div class="fill" style="width:${b.percent}%"></div></div>
                  <div class="muted">${b.note}</div>
                </div>
              `).join('')}
            </div>
          </div>

          <div class="result-card">
            <div class="rc-head"><span class="rc-no">05</span><span class="rc-title">節約ポイント</span></div>
            <div class="rc-body"><ul>${active.savingPoints.map(p=>`<li>${p}</li>`).join('')}</ul></div>
          </div>
        </div>

        <div class="second-opinion-banner mt-6">
          <span class="eyebrow">FREE SECOND OPINION</span>
          <h3>このプラン、本当に大丈夫？</h3>
          <p>AIの提案はあくまで「たたき台」です。現地の高さ・勾配・法規制によって最適なプランは変わります。第三者目線のプロが、500件以上の実績をもとに無料でセカンドオピニオンを行います。</p>
          <div class="banner-actions">
            <button class="btn" id="reserve-btn-top">無料相談を申し込む</button>
            <a class="btn btn-light-outline" id="zoom-btn-top" href="${cfg.ZOOM_URL}" target="_blank" rel="noopener">今すぐZoomで相談する</a>
          </div>
        </div>

        <div class="result-cards">
          <div class="result-card">
            <div class="rc-head"><span class="rc-no">06</span><span class="rc-title">優先順位</span></div>
            <div class="rc-body"><ul>${a.priorities.map((p,i)=>`<li>${i+1}. ${p.label.replace(/^[①-⑥]/,'')}</li>`).join('')}</ul></div>
          </div>

          <div class="result-card">
            <div class="rc-head"><span class="rc-no">07</span><span class="rc-title">動線設計</span></div>
            <div class="rc-body">${proposal.flow}</div>
          </div>

          <div class="result-card">
            <div class="rc-head"><span class="rc-no">08</span><span class="rc-title">植栽提案</span></div>
            <div class="rc-body">${proposal.planting}</div>
          </div>

          <div class="result-card">
            <div class="rc-head"><span class="rc-no">09</span><span class="rc-title">将来性</span></div>
            <div class="rc-body">${proposal.future}</div>
          </div>

          <div class="result-card">
            <div class="rc-head"><span class="rc-no">10</span><span class="rc-title">DIYアドバイス</span></div>
            <div class="rc-body"><ul>${proposal.diyAdvice.map(p=>`<li>${p}</li>`).join('')}</ul></div>
          </div>
        </div>

        <div class="share-row">
          <button class="btn btn-outline" id="share-btn">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 12v7a1 1 0 0 0 1 1h14a1 1 0 0 0 1-1v-7"/><path d="M16 6l-4-4-4 4"/><path d="M12 2v13"/></svg>
            シェア
          </button>
          <button class="btn btn-outline" id="instagram-btn">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="2" width="20" height="20" rx="5"/><circle cx="12" cy="12" r="4"/><circle cx="17.5" cy="6.5" r="0.6" fill="currentColor"/></svg>
            Instagramでシェア
          </button>
        </div>

        <div class="disclaimer">
          <strong>AI画像・金額・評価はあくまでイメージです。</strong>
          外構は高さ・勾配・排水・生活動線・施工性によって大きく変わります。
          500件以上の実績から、第三者目線でのセカンドオピニオンを無料で行っています。
        </div>

        <div class="cta-block">
          <button class="btn btn-accent" id="reserve-btn">無料相談を申し込む</button>
          <p class="muted">所要時間 約15分・オンライン可・Zoom対応</p>
          <button class="btn btn-outline mt-4" id="retry-btn">もう一度診断する</button>
        </div>
      </main>
    `;

    document.getElementById('exit-btn').addEventListener('click', () => {
      state.screen = 'top'; render();
    });
    document.getElementById('retry-btn').addEventListener('click', () => {
      state.screen = 'top'; render();
    });
    document.getElementById('reserve-btn').addEventListener('click', () => {
      state.showReserve = true; renderReserveModal();
    });
    document.getElementById('reserve-btn-top').addEventListener('click', () => {
      state.showReserve = true; renderReserveModal();
    });
    document.querySelectorAll('#pattern-tabs .pattern-tab').forEach(btn => {
      btn.addEventListener('click', () => {
        state.activePattern = parseInt(btn.dataset.pattern, 10);
        renderResult();
      });
    });
    document.getElementById('share-btn').addEventListener('click', () => shareResult(active));
    document.getElementById('instagram-btn').addEventListener('click', () => shareToInstagram(active));
    document.getElementById('save-image-btn').addEventListener('click', () => renderSaveImageModal(active));
    const retryBtn = document.getElementById('retry-image-btn');
    if(retryBtn){
      retryBtn.addEventListener('click', () => {
        retryPatternImage(parseInt(retryBtn.dataset.pattern, 10));
      });
    }
  }

  // 指定パターンの完成イメージを再生成する（「もう一度生成する」ボタン）
  async function retryPatternImage(index){
    const proposal = state.result.proposal;
    const p = proposal.patterns[index];
    if(!p) return;
    p.imageLoading = true;
    p.imageNote = null;
    if(state.activePattern === index) renderResult();

    const a = state.answers;
    const apiAnswers = buildApiAnswers(a);
    const result = await fetchImage(a, apiAnswers, p.key);

    p.imageUrl = result.imageUrl;
    p.imageNote = result.note;
    p.imageLoading = false;
    persistLastImages(proposal);
    if(state.activePattern === index) renderResult();
  }

  /* ----------------------------------------------------------
     診断結果のシェア
     ---------------------------------------------------------- */
  async function shareResult(pattern){
    const shareData = {
      title: cfg.BRAND.name,
      text: `AIで外構診断をしてみました。「${pattern.label}」プランの概算は${pattern.estimatedCost.min}〜${pattern.estimatedCost.max}万円でした。`,
      url: location.href.split('#')[0]
    };
    const btn = document.getElementById('share-btn');
    try{
      if(navigator.share){
        await navigator.share(shareData);
      } else {
        await navigator.clipboard.writeText(`${shareData.text}\n${shareData.url}`);
        if(btn){
          const original = btn.innerHTML;
          btn.innerHTML = 'リンクをコピーしました';
          setTimeout(() => { btn.innerHTML = original; }, 1800);
        }
      }
    }catch(e){ /* ユーザーがシェアをキャンセルした場合などは無視 */ }
  }

  /* ----------------------------------------------------------
     Instagramシェア
     ---------------------------------------------------------- */
  async function shareToInstagram(pattern){
    const caption = `AIで外構診断をしてみました📐\n`
      + `「${pattern.label}」プランの総合評価は${pattern.score.total}点、概算は${pattern.estimatedCost.min}〜${pattern.estimatedCost.max}万円でした。\n`
      + `#外構 #エクステリア #AI外構コンシェルジュ ${cfg.INSTAGRAM.handle}`;

    const btn = document.getElementById('instagram-btn');
    const setLabel = (html) => {
      if(!btn) return;
      const original = btn.innerHTML;
      btn.innerHTML = html;
      setTimeout(() => { btn.innerHTML = original; }, 2200);
    };

    try{
      // 画像をWeb Share APIでファイル共有できる場合（対応端末のみ）
      if(pattern.imageUrl && navigator.canShare){
        const res = await fetch(pattern.imageUrl);
        const blob = await res.blob();
        const file = new File([blob], 'gaikou-plan.png', { type: blob.type || 'image/png' });
        if(navigator.canShare({ files:[file] })){
          await navigator.share({ files:[file], title: cfg.BRAND.name, text: caption });
          return;
        }
      }
      await navigator.clipboard.writeText(caption);
      window.open(cfg.INSTAGRAM.url, '_blank', 'noopener');
      setLabel('キャプションをコピーしました');
    }catch(e){
      setLabel('共有をキャンセルしました');
    }
  }

  /* ----------------------------------------------------------
     画像保存（LINE登録モーダル）
     ---------------------------------------------------------- */
  function renderSaveImageModal(pattern){
    let modal = document.getElementById('save-image-modal');
    if(modal) modal.remove();
    modal = document.createElement('div');
    modal.id = 'save-image-modal';
    modal.className = 'modal-backdrop';

    const hasImage = !!pattern.imageUrl;

    modal.innerHTML = `
      <div class="modal-sheet bracket accent">
        <span class="br-tr"></span><span class="br-bl"></span>
        <span class="eyebrow">SAVE IMAGE</span>
        <h2>完成イメージを保存</h2>
        <p class="muted">公式LINEにご登録いただくと、「${pattern.label}」の完成イメージ画像を高画質で保存できます。今後のお得な情報・無料相談予約もLINEから簡単に行えます。</p>
        <div class="modal-actions" style="flex-direction:column;">
          <a class="btn btn-primary" href="${cfg.LINE_ADD_FRIEND_URL}" target="_blank" rel="noopener" id="line-add-btn">公式LINEに登録する</a>
          ${hasImage
            ? `<a class="btn btn-outline" href="${pattern.imageUrl}" download="gaikou-${pattern.key}.png" id="download-img-btn">登録済みの方はこちら（画像をダウンロード）</a>`
            : `<p class="muted center">この画像は現在生成中です。LINE登録後、担当より高画質イメージをお送りします。</p>`}
          <button class="btn btn-text" id="save-modal-close">閉じる</button>
        </div>
      </div>
    `;
    document.body.appendChild(modal);
    modal.addEventListener('click', (e) => { if(e.target === modal) modal.remove(); });
    document.getElementById('save-modal-close').addEventListener('click', () => modal.remove());
  }

  /* ----------------------------------------------------------
     相談予約モーダル
     ---------------------------------------------------------- */
  function renderReserveModal(){
    let modal = document.getElementById('reserve-modal');
    if(modal) modal.remove();
    modal = document.createElement('div');
    modal.id = 'reserve-modal';
    modal.className = 'modal-backdrop';
    modal.innerHTML = `
      <div class="modal-sheet bracket accent">
        <span class="br-tr"></span><span class="br-bl"></span>
        <span class="eyebrow">FREE CONSULTATION</span>
        <h2>無料相談のお申し込み</h2>
        <p class="muted">第三者目線でのセカンドオピニオンをご希望の方は、以下にご入力ください。</p>
        <div class="field"><label class="field-label">お名前</label><input type="text" id="rv-name" placeholder="山田 太郎"></div>
        <div class="field"><label class="field-label">ご連絡先（電話 or メール）</label><input type="text" id="rv-contact" placeholder="090-xxxx-xxxx / example@mail.com"></div>
        <div class="field"><label class="field-label">ご希望の相談方法</label>
          <select id="rv-method">
            <option value="zoom">Zoom（おすすめ）</option>
            <option value="online">その他オンライン</option>
            <option value="visit">現地</option>
            <option value="phone">電話</option>
          </select>
        </div>
        <div class="field"><label class="field-label">ご質問・ご要望（任意）</label><textarea id="rv-message" placeholder="気になる点があればご記入ください"></textarea></div>
        <div class="modal-actions">
          <button class="btn btn-outline" id="rv-cancel">閉じる</button>
          <button class="btn btn-primary" id="rv-submit">送信する</button>
        </div>
        <p class="muted center mt-4" id="rv-status"></p>
      </div>
    `;
    document.body.appendChild(modal);

    document.getElementById('rv-cancel').addEventListener('click', () => modal.remove());
    modal.addEventListener('click', (e) => { if(e.target === modal) modal.remove(); });

    document.getElementById('rv-submit').addEventListener('click', async () => {
      const name = document.getElementById('rv-name').value.trim();
      const contact = document.getElementById('rv-contact').value.trim();
      if(!name || !contact){
        document.getElementById('rv-status').textContent = 'お名前とご連絡先をご入力ください。';
        return;
      }
      const reservation = {
        name,
        contact,
        method: document.getElementById('rv-method').value,
        message: document.getElementById('rv-message').value.trim(),
        diagnosis_summary: {
          atmosphere: state.answers.atmosphere,
          exteriorStyle: state.answers.exteriorStyle,
          budget: state.answers.budget
        }
      };

      document.getElementById('rv-status').textContent = '送信中…';
      try{
        const saved = await DB.saveReservation(reservation);
        // Googleスプレッドシート/LINE通知（任意・未設定でも握りつぶす）
        fetch(cfg.NOTIFY_API, {
          method:'POST',
          headers:{'Content-Type':'application/json'},
          body: JSON.stringify({ type:'reservation', data: saved })
        }).catch(()=>{});

        modal.innerHTML = `
          <div class="modal-sheet bracket accent center">
            <span class="br-tr"></span><span class="br-bl"></span>
            <span class="eyebrow">SUBMITTED</span>
            <h2>送信が完了しました</h2>
            <p class="lead mt-4">担当よりご連絡いたします。<br>お問い合わせありがとうございました。</p>
            <button class="btn btn-primary mt-6" id="rv-close">閉じる</button>
          </div>`;
        document.getElementById('rv-close').addEventListener('click', () => modal.remove());
      }catch(e){
        document.getElementById('rv-status').textContent = '送信に失敗しました。時間を置いて再度お試しください。';
      }
    });
  }

  /* ----------------------------------------------------------
     ルーター
     ---------------------------------------------------------- */
  function render(){
    if(state.screen !== 'loading' && state.loadingInterval){
      clearInterval(state.loadingInterval);
      state.loadingInterval = null;
    }
    switch(state.screen){
      case 'top': renderTop(); break;
      case 'step': renderStep(); break;
      case 'loading': renderLoading(); break;
      case 'result': renderResult(); break;
      default: renderTop();
    }
    window.scrollTo(0,0);
  }

  render();

  /* ----------------------------------------------------------
     PWA：Service Worker登録
     ---------------------------------------------------------- */
  if('serviceWorker' in navigator){
    window.addEventListener('load', () => {
      navigator.serviceWorker.register('/sw.js').catch(()=>{});
    });
  }
})();
