/* ============================================================
   POST /.netlify/functions/generate-image
   外構完成イメージの画像生成プロキシ。

   - モデル: gpt-image-1（最新のOpenAI Images API。dall-e-2/3は使用しない）
   - response_format パラメータは送信しない（gpt-image-1は常にb64_jsonを返す）
   - 各試行は最大25秒でタイムアウト。429/5xx/タイムアウト時は最大2回リトライ（計3回）
   - 失敗時も例外を投げず、必ず success:false のJSONを返す（フロント側の画面崩壊を防止）

   必要な環境変数:
     OPENAI_API_KEY ... OpenAI APIキー

   レスポンス形式（常にこの形で返す・HTTP 200固定）:
     {
       success: boolean,
       imageUrl: string | null,    // <img src>にそのまま使える形式（dataURI or http URL）
       imageBase64: string | null, // 生のbase64文字列（プレフィックスなし）。url形式の場合はnull
       error: string | null
     }
   ============================================================ */

function respond(payload){
  return {
    statusCode: 200,
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload)
  };
}

/**
 * 環境変数を取得する。
 * 値の前後の空白・改行（Netlifyの環境変数UIへのコピペ時に混入しやすい）を除去し、
 * 完全一致するキーが無い場合は大文字小文字を無視して再検索する。
 */
function getEnv(name){
  let v = process.env[name];
  if (v === undefined) {
    const altKey = Object.keys(process.env).find(k => k.toUpperCase() === name.toUpperCase());
    if (altKey) v = process.env[altKey];
  }
  if (typeof v === 'string') v = v.trim();
  return v || undefined;
}

/**
 * OpenAI Images API を1回呼び出す。
 * - response_format は使用しない（gpt-image-1は常にb64_jsonを返す）
 * - dall-e-2 等の旧モデルは使用しない（現行の gpt-image-1 を使用）
 * - AbortControllerでタイムアウトを設定し、ハング状態を防ぐ
 */
async function callOpenAIOnce(prompt, openaiKey, timeoutMs){
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const res = await fetch('https://api.openai.com/v1/images/generations', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${openaiKey}`
      },
      signal: controller.signal,
      body: JSON.stringify({
        model: 'gpt-image-1',
        prompt: prompt,
        size: '1024x1024',
        n: 1
        // response_format は指定しない（gpt-image-1では未対応のパラメータ）
      })
    });

    console.log('generate-image: OpenAI response status =', res.status);
    const rawText = await res.text();

    if (!res.ok) {
      console.error('generate-image: OpenAI API error', res.status, rawText.slice(0, 1000));
      return { success:false, retryable: res.status === 429 || res.status >= 500,
        error: `OpenAI APIエラー (HTTP ${res.status}): ${rawText.slice(0, 500)}` };
    }

    let data;
    try {
      data = JSON.parse(rawText);
    } catch (parseErr) {
      console.error('generate-image: failed to parse OpenAI response JSON', parseErr, rawText.slice(0, 500));
      return { success:false, retryable:true, error: `OpenAI応答のJSON解析に失敗しました: ${rawText.slice(0, 300)}` };
    }

    console.log('generate-image: OpenAI response top-level keys =', Object.keys(data));

    const item = data.data && data.data[0];
    const imageBase64 = (item && item.b64_json) || null;
    const directUrl = (item && item.url) || null;

    console.log('generate-image: imageBase64 present =', !!imageBase64, ' url present =', !!directUrl);

    if (!imageBase64 && !directUrl) {
      console.error('generate-image: unexpected response shape', JSON.stringify(data).slice(0, 1000));
      return { success:false, retryable:true, error: `想定外のレスポンス形式です: ${JSON.stringify(data).slice(0, 300)}` };
    }

    const imageUrl = directUrl || `data:image/png;base64,${imageBase64}`;
    console.log('generate-image: success, source =', directUrl ? 'url' : 'b64_json');
    return { success:true, imageUrl, imageBase64: imageBase64 || null };

  } catch (e) {
    const aborted = e && e.name === 'AbortError';
    console.error('generate-image: fetch failed', aborted ? 'TIMEOUT' : e);
    return {
      success:false, retryable:true,
      error: aborted ? `OpenAIへのリクエストがタイムアウトしました (${timeoutMs}ms)` : `Internal error: ${String(e)}`
    };
  } finally {
    clearTimeout(timer);
  }
}

function sleep(ms){ return new Promise(r => setTimeout(r, ms)); }

exports.handler = async (event) => {
  // デバッグ用：この行のログがNetlifyのFunction logsに表示されない場合、
  // フロントエンドからのリクエストがこの関数まで届いていないことを意味します。
  console.log('start: generate-image invoked', {
    method: event.httpMethod,
    hasBody: !!event.body,
    isBase64Encoded: event.isBase64Encoded
  });

  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, body: JSON.stringify({ error: 'Method Not Allowed' }) };
  }

  let rawBody = event.body || '{}';
  if (event.isBase64Encoded) {
    rawBody = Buffer.from(rawBody, 'base64').toString('utf-8');
  }

  let body;
  try {
    body = JSON.parse(rawBody);
  } catch (e) {
    console.error('generate-image: Invalid JSON body', e, rawBody);
    return respond({ success:false, imageUrl:null, imageBase64:null, error:'Invalid JSON body' });
  }

  const prompt = body.prompt || '';
  const pattern = body.pattern || 'default';
  console.log('generate-image: pattern =', pattern, ' prompt length =', prompt.length);

  const openaiKey = getEnv('OPENAI_API_KEY');

  // デバッグ用：値そのものは出力せず、読み取り状況のみログに出す
  console.log('generate-image: OPENAI_API_KEY readable =', !!openaiKey,
    ' length =', openaiKey ? openaiKey.length : 0);

  if (!openaiKey) {
    const openaiLikeKeys = Object.keys(process.env).filter(k => k.toUpperCase().includes('OPENAI'));
    console.error('generate-image: OPENAI_API_KEY is not readable from process.env.', {
      'OPENAI関連のキー名一覧（値は表示しません）': openaiLikeKeys,
      '環境変数の総数': Object.keys(process.env).length
    });
    return respond({
      success:false, imageUrl:null, imageBase64:null,
      error: 'OPENAI_API_KEYをFunction内から読み取れませんでした。Netlifyで環境変数を追加・変更した後は'
        + '再デプロイ（Deploys → Trigger deploy → Clear cache and deploy site）が必要です。'
        + (openaiLikeKeys.length ? ` 関連しそうなキー: ${openaiLikeKeys.join(', ')}` : ' OPENAIを含む環境変数は見つかりませんでした。')
    });
  }

  // Netlify Functionの実行時間には上限があるため（netlify.tomlでgenerate-imageは30秒に設定）、
  // 全体の予算（TOTAL_BUDGET_MS）内で「初回 + 最大2回リトライ」を行う。
  // 残り時間が少ない場合はリトライをスキップし、success:false を返す。
  const startedAt = Date.now();
  const TOTAL_BUDGET_MS = 27000; // 関数タイムアウト(30s)より少し短く設定
  const MAX_ATTEMPTS = 3;
  const MIN_ATTEMPT_TIMEOUT_MS = 6000;
  let lastResult = null;

  for (let attempt = 1; attempt <= MAX_ATTEMPTS; attempt++) {
    const elapsed = Date.now() - startedAt;
    const remaining = TOTAL_BUDGET_MS - elapsed;
    if (remaining < MIN_ATTEMPT_TIMEOUT_MS) {
      console.warn(`generate-image: remaining time ${remaining}ms が不足しているため試行${attempt}をスキップします`);
      break;
    }
    const perAttemptTimeout = Math.min(20000, remaining - 1000);

    console.log(`generate-image: attempt ${attempt}/${MAX_ATTEMPTS} (timeout=${perAttemptTimeout}ms, remaining=${remaining}ms)`);
    lastResult = await callOpenAIOnce(prompt, openaiKey, perAttemptTimeout);

    if (lastResult.success) {
      return respond({
        success: true,
        imageUrl: lastResult.imageUrl,
        imageBase64: lastResult.imageBase64 || null,
        error: null
      });
    }

    console.warn(`generate-image: attempt ${attempt} failed`, lastResult.error);

    if (attempt < MAX_ATTEMPTS && lastResult.retryable) {
      const remainingAfter = TOTAL_BUDGET_MS - (Date.now() - startedAt);
      const backoff = Math.min(1000 * attempt, Math.max(0, remainingAfter - MIN_ATTEMPT_TIMEOUT_MS));
      if (backoff > 0) await sleep(backoff);
      continue;
    }
    break;
  }

  // 全試行が失敗した場合も、画面が壊れないよう success:false のJSONを返す
  return respond({
    success: false,
    imageUrl: null,
    imageBase64: null,
    error: (lastResult && lastResult.error) || '画像生成に失敗しました。'
  });
};
