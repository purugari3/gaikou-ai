/* ============================================================
   POST /.netlify/functions/notify
   診断完了・相談予約をGoogleスプレッドシート / LINEへ通知します。

   必要な環境変数（いずれも任意・未設定の場合はスキップされます）:
     GAS_WEBHOOK_URL   ... Google Apps Script のWebアプリ公開URL
                           （Apps Script側でスプレッドシートへの書き込み・
                            LINE Notify送信などを行う想定。サンプルは
                            README.md を参照してください）
     LINE_NOTIFY_TOKEN ... LINE Notify のアクセストークン
                           （GASを使わず直接LINEへ通知したい場合に使用）

   リクエスト形式:
     { type: 'diagnosis' | 'reservation', data: {...} }
   ============================================================ */

/**
 * 環境変数を取得する（前後の空白除去・キー名の大文字小文字を無視して検索）。
 */
function getEnv(name){
  let v = process.env[name];
  if (v === undefined) {
    const altKey = Object.keys(process.env).find(k => k.toUpperCase() === name.toUpperCase());
    if (altKey) v = process.env[altKey];
  }
  if (typeof v === 'string') v = v.trim();
  return v || undefined;
}

exports.handler = async (event) => {
  console.log('start: notify invoked', { method: event.httpMethod, hasBody: !!event.body });

  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, body: JSON.stringify({ error: 'Method Not Allowed' }) };
  }

  let body;
  try {
    body = JSON.parse(event.body || '{}');
  } catch (e) {
    return { statusCode: 400, body: JSON.stringify({ error: 'Invalid JSON body' }) };
  }

  const { type, data } = body;
  const results = {};

  const gasUrl = getEnv('GAS_WEBHOOK_URL');
  if (gasUrl) {
    try {
      const res = await fetch(gasUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ type, data })
      });
      results.sheets = res.ok ? 'ok' : `error: ${res.status}`;
    } catch (e) {
      results.sheets = `error: ${String(e)}`;
    }
  } else {
    results.sheets = 'skipped (GAS_WEBHOOK_URL not set)';
  }

  const lineToken = getEnv('LINE_NOTIFY_TOKEN');
  if (lineToken) {
    try {
      const message = buildLineMessage(type, data);
      const params = new URLSearchParams();
      params.append('message', message);

      const res = await fetch('https://notify-api.line.me/api/notify', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${lineToken}`,
          'Content-Type': 'application/x-www-form-urlencoded'
        },
        body: params.toString()
      });
      results.line = res.ok ? 'ok' : `error: ${res.status}`;
    } catch (e) {
      results.line = `error: ${String(e)}`;
    }
  } else {
    results.line = 'skipped (LINE_NOTIFY_TOKEN not set)';
  }

  return {
    statusCode: 200,
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ ok: true, results })
  };
};

function buildLineMessage(type, data) {
  if (type === 'reservation') {
    return `\n【無料相談の申し込み】\nお名前: ${data.name}\n連絡先: ${data.contact}\n方法: ${data.method}\nご要望: ${data.message || 'なし'}`;
  }
  if (type === 'diagnosis') {
    const a = (data && data.answers) || {};
    return `\n【AI外構コンシェルジュ 完了】\n雰囲気: ${a.atmosphere || '-'}\nスタイル: ${a.exteriorStyle || '-'}\n予算: ${a.budget || '-'}`;
  }
  return `\n【AI外構コンシェルジュ】通知\n${JSON.stringify(data)}`;
}
