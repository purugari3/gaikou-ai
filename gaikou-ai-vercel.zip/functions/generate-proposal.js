/* ============================================================
   POST /.netlify/functions/generate-proposal
   診断回答(answers)を受け取り、Claude APIで外構プラン提案文をJSON生成します。

   必要な環境変数:
     ANTHROPIC_API_KEY  ... Anthropic APIキー（Netlifyの環境変数に設定）

   レスポンス形式:
     {
       patterns: [
         {
           key, label, icon, highlight,
           estimatedCost:{min,max},
           concept, points:[],
           budgetAllocation:[{label,percent,note}],
           score:{ total, breakdown:[{label,value}] },
           savingPoints:[]
         },
         ... (budget / design / flow の3パターン)
       ],
       flow: string,
       planting: string,
       future: string,
       diyAdvice: string[]
     }
   ============================================================ */

const ANTHROPIC_API_URL = 'https://api.anthropic.com/v1/messages';
const MODEL = 'claude-sonnet-4-6';

/**
 * 環境変数を取得する。
 * 値の前後の空白・改行（Netlifyの環境変数UIへのコピペ時に混入しやすい）を除去し、
 * 完全一致するキーが無い場合は大文字小文字を無視して再検索する。
 */
function getEnv(name){
  let v = process.env[name];
  if (v === undefined) {
    const altKey = Object.keys(process.env).find(k => k.toUpperCase() === name.toUpperCase());
    if (altKey) v = process.env[altKey];
  }
  if (typeof v === 'string') v = v.trim();
  return v || undefined;
}

exports.handler = async (event) => {
  console.log('start: generate-proposal invoked', { method: event.httpMethod, hasBody: !!event.body });

  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, body: JSON.stringify({ error: 'Method Not Allowed' }) };
  }

  const apiKey = getEnv('ANTHROPIC_API_KEY');
  console.log('generate-proposal: ANTHROPIC_API_KEY readable =', !!apiKey, ' length =', apiKey ? apiKey.length : 0);

  if (!apiKey) {
    const likeKeys = Object.keys(process.env).filter(k => k.toUpperCase().includes('ANTHROPIC'));
    console.error('generate-proposal: ANTHROPIC_API_KEY is not readable from process.env.', {
      'ANTHROPIC関連のキー名一覧（値は表示しません）': likeKeys,
      '環境変数の総数': Object.keys(process.env).length
    });
    return {
      statusCode: 501,
      body: JSON.stringify({ error: 'ANTHROPIC_API_KEY is not configured (or not readable). 環境変数追加後は再デプロイが必要です。フロントエンドはローカル提案文にフォールバックします。' })
    };
  }

  let answers;
  try {
    let rawBody = event.body || '{}';
    if (event.isBase64Encoded) {
      rawBody = Buffer.from(rawBody, 'base64').toString('utf-8');
    }
    answers = JSON.parse(rawBody).answers || {};
  } catch (e) {
    console.error('generate-proposal: Invalid JSON body', e);
    return { statusCode: 400, body: JSON.stringify({ error: 'Invalid JSON body' }) };
  }

  const system = `あなたは日本の外構（エクステリア）専門のプランナーです。
ユーザーの回答内容（JSON）から、外構プラン提案を「予算重視」「デザイン重視」「動線重視」の3パターンで作成してください。
出力は必ず以下のJSON形式のみで、説明文やMarkdownのコードブロックは含めないでください。

{
  "patterns": [
    {
      "key": "budget",
      "label": "予算重視",
      "icon": "BUDGET",
      "highlight": "1行のキャッチコピー（30文字程度）",
      "estimatedCost": {"min": 数値(万円), "max": 数値(万円)},
      "concept": "このパターンのコンセプト文（150〜250文字程度、日本語）",
      "points": ["メリット1", "メリット2", "メリット3〜4個"],
      "budgetAllocation": [
        {"label": "カテゴリ名", "percent": 数値(合計100), "note": "補足説明"}
      ],
      "score": {
        "total": 数値(0-100),
        "breakdown": [
          {"label": "デザイン性", "value": 数値(0-100)},
          {"label": "予算適正", "value": 数値(0-100)},
          {"label": "動線", "value": 数値(0-100)},
          {"label": "将来性", "value": 数値(0-100)}
        ]
      },
      "savingPoints": ["節約ポイント1", "節約ポイント2", "節約ポイント3"]
    },
    { "key": "design", "label": "デザイン重視", "icon": "DESIGN", ... 同様の構造 },
    { "key": "flow", "label": "動線重視", "icon": "FLOW", ... 同様の構造 }
  ],
  "flow": "生活動線についての提案文（3パターン共通、日本語、改行は\\nで表現）",
  "planting": "植栽提案文（3パターン共通、日本語）",
  "future": "将来性・メンテナンス等についての提案文（3パターン共通、日本語、改行は\\nで表現）",
  "diyAdvice": ["DIYアドバイス1", "DIYアドバイス2", "DIYアドバイス3〜4個"]
}

各パターンのscore.totalはbreakdownの平均値を目安にしてください。
3パターンは、それぞれの観点（コスト効率／デザイン性／暮らしやすさ）でtotalや各breakdown値に明確な差をつけてください（同じ値を並べない）。
savingPointsはそのパターンの観点に沿った、実践的なコスト削減アイデアにしてください。
diyAdviceは、施工店に依頼すべき部分とDIYで対応可能な部分を区別して具体的に記載してください。
予算(estimatedCost)はユーザーが回答した予算帯を参考に、現実的な金額レンジ（万円単位）にしてください。
3パターンは似たような内容にならないよう、それぞれの観点（コスト効率／デザイン性／暮らしやすさ）を明確に反映してください。
トーンは専門性・信頼感・高級感を重視し、営業色を出さないでください。`;

  const userMessage = `以下は診断フォームの回答です。この内容に基づいて外構プランを提案してください。\n\n${JSON.stringify(answers, null, 2)}`;

  try {
    const res = await fetch(ANTHROPIC_API_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': apiKey,
        'anthropic-version': '2023-06-01'
      },
      body: JSON.stringify({
        model: MODEL,
        max_tokens: 3000,
        system,
        messages: [{ role: 'user', content: userMessage }]
      })
    });

    console.log('generate-proposal: Anthropic response status =', res.status);

    if (!res.ok) {
      const errText = await res.text();
      console.error('generate-proposal: Anthropic API error', res.status, errText);
      return { statusCode: 502, body: JSON.stringify({ error: 'Anthropic API error', detail: errText }) };
    }

    const data = await res.json();
    const text = (data.content || [])
      .filter((b) => b.type === 'text')
      .map((b) => b.text)
      .join('\n')
      .trim();

    const cleaned = text.replace(/^```json\s*/i, '').replace(/```\s*$/, '').trim();

    let proposal;
    try {
      proposal = JSON.parse(cleaned);
    } catch (parseErr) {
      console.error('generate-proposal: failed to parse JSON from Claude', parseErr, cleaned.slice(0, 500));
      return { statusCode: 502, body: JSON.stringify({ error: 'Failed to parse proposal JSON', detail: String(parseErr) }) };
    }

    return {
      statusCode: 200,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(proposal)
    };
  } catch (e) {
    console.error('generate-proposal: Internal error', e);
    return { statusCode: 500, body: JSON.stringify({ error: 'Internal error', detail: String(e) }) };
  }
};
