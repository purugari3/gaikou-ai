const fn = require('../functions/notify.js');

module.exports = async (req, res) => {
  const event = {
    httpMethod: req.method,
    headers: req.headers,
    body: req.body ? (typeof req.body === 'string' ? req.body : JSON.stringify(req.body)) : '',
    isBase64Encoded: false
  };

  try {
    const result = await fn.handler(event);
    const statusCode = result.statusCode || 200;
    const headers = result.headers || {};
    Object.entries(headers).forEach(([key, value]) => res.setHeader(key, value));
    res.status(statusCode).send(result.body || '');
  } catch (error) {
    console.error('notify wrapper error:', error);
    res.status(500).json({ error: String(error && error.message ? error.message : error) });
  }
};
